var server = require('../../utils/server');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        url: app.globalData.url,
        picture: '',
        cate_list: [],
        screenArray: [],
        currentTab: 0,
        scrollTop: 0,
        childrenArray: [],
    },
    navbarTap: function (e) {
        var that = this;
        console.log(e);
        this.setData({
            currentTab: e.currentTarget.id,   //按钮CSS变化
            screenId: e.currentTarget.dataset.screenid,
            scrollTop: 0,   //切换导航后，控制右侧滚动视图回到顶部
        })
        console.log(this.currentTab)
        //刷新右侧内容的数据
        // var screenId = this.data.screenId;
        // request.sendRrquest(API_queryClassify, 'POST', { flag: 1, screenId: screenId }, )
        //   .then(function (res) {
        //     console.log("返回数据：");
        //     that.setData({
        //       childrenArray: res.data.data.screenArray[0],
        //     })
        //     console.log(that.data.childrenArray);
        //   }, function (error) { console.log("返回失败"); });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        this.loadCate();
    },
    gosearch:function(){
        wx.navigateTo({
            url: '../other/search/search',
        })
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.loadCate();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    //下拉刷新
    onPullDownRefresh: function () {
        wx.showNavigationBarLoading() //在标题栏中显示加载  
        //模拟加载
        setTimeout(function () {
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
        }, 1000);
        this.loadCate();
    },
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },

    loadCate: function () {
        var that = this;
        server.getJSON("/Goods/category_first", function (res) {
            var picture = res.data.result.adv;
            var cate_list = res.data.result.cate_list;
            that.setData({
                picture: picture,
                cate_list: cate_list
            });
        });
    },

    goodsCate: function (e) {
        var Id = e.currentTarget.dataset.cateid;
        console.log(Id);
        wx.navigateTo({
            url: '../goods/list/list?objectId=' + Id,
        })
    },

    bindViewTap: function (e) {
        var jump_type = e.currentTarget.dataset.jumpType;
        var jump_url = e.currentTarget.dataset.jumpUrl;

        if (jump_type == 0) {
            wx.navigateTo({
                url: "../goods/ceshi/ceshi?objectId=" + jump_url,
            });
        } else if (jump_type == 1) {
            wx.navigateTo({
                url: "../goods/details/details?objectId=" + jump_url,
            });
        } else if (jump_type == 2) {
            wx.navigateTo({
                url: "../goods/list/list?objectId=" + jump_url,
            });
        } else {
            url: "../goods/activity_goods/activity_goods?objectId=" + jump_url
        }
    }
})
