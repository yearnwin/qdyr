var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    mobile: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.userInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  userInfo: function () {
    var wxtoken = wx.getStorageSync('wxtoken');
    server.getJSON('/Cart/users/wxtoken/' + wxtoken, function (res) {
      if (res.data.status == -1) {
        wx.navigateTo({
          url: '../../wode/choice/choice',
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
  //下拉刷新
  onPullDownRefresh:function(){
    
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getUsername: function (e) {
    this.setData({
      username: e.detail.value,
    });
  },
  getMobile: function (e) {
    this.setData({
      mobile: e.detail.value,
    });
  },
  isPanter: function () {
    var that = this;
    var username = that.data.username;
    var mobile = that.data.mobile;
    console.log(username); 
    console.log(mobile); 
    if(username == ''){
      wx.showToast({
        title: '请输入姓名',
      })
    }else if (mobile == '') {
      wx.showToast({
        title: '请输入手机号',
      })
    }else{
      server.getJSON('/User/paidang/wxtoken/' + wx.getStorageSync('wxtoken') + '/username/' + username + '/phone/' + mobile, function (res) {   

        wx.showToast({
          title: res.data.msg,
        })
        
      });
    }
  }
})