// pages/set/name_firm/name_firm.js
var server = require('../../../utils/server');
var app = getApp();
Page({
  data:{
    organization:'',
  },
  onLoad: function () {
    var that = this;
    server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      console.log(res.data.result.info);
      var organization = res.data.result.info.organization;
      that.setData({
        organization: organization,

      })

    });

  },
 name_firm:function(e){
      var organization=e.detail.value.organization;
      console.log(organization);
    if (organization == '') {
      wx.showToast({
        title: '请输入公司名称',
      })
    } else {
      wx.request({
        url: app.globalData.url + '/wxapi/User/userinfo',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          organization: organization,
        },
        method: 'POST',
        success(res) {
          if (res.data.status == 1) {
           console.log(res)
            wx.navigateTo({
              url: '../security/security',
            })
          } else {
            wx.showToast({
              title: res.data.msg
            })
          }
        }
      })
    }
  },

//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },



})