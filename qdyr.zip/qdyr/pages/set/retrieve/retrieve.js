var server = require('../../../utils/server');
var app = getApp();
var maxTime = 60
var interval = null
var currentTime = -1 //倒计时的事件（单位：s
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    password: '',
    password2: '',
    code: '',
    time: '获取验证码',

  },
  phoneInput: function (e) {
    let username = e.detail.value;
    if (username.length == 0) {
      this.setData({
        phoneTip: '手机号不能为空'
      })
    }else {
      this.setData({
        phoneTip: '',
        username: username,
        boolean: false
      })
    }
  },  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  forget:function(e){
    console.log(e)
    var that = this;
    var unique = 'fsubdfussdbfisbbsjvcsdbf';
    var username = e.detail.value.username;
    var code = e.detail.value.code;
    var password = e.detail.value.password;
    var password2 = e.detail.value.password2;

    // let avatarUrl = wx.getStorageSync('avatarUrl'); 
    if (username == '') {
      wx.showToast({
        title: '请输入手机号',
        icon: 'none',
      });
      return false;
    }

    if (code == '') {
      wx.showToast({
        title: '请输入验证码',
        icon: 'none',

      });
      return false;
    }
    if (password == '') {
      wx.showToast({
        title: '密码不能为空',
        icon: 'none',

      });
      return false;
    }
    if (password2 == '') {
      wx.showToast({
        title: '请输入确认密码',
        icon: 'none',

      });
      return false;
    }
    if (password != password2) {
      wx.showToast({
        title: '确认密码不一致',
        icon: 'none',

      });
      return false;
    }
    wx.request({
      url: app.globalData.url + '/wxapi/LoginApi/findpwd',
      data: { mobile_code: code, username: username, password: password, password2: password2, unique: unique },
      success: res => {
        //成功的话直接跳转到个人中心       
        var oStatus = res.data.status;
        console.log(res)
        if (oStatus == 1) {
          // var session_id = res.data.session_id;         
          wx.setStorageSync('wxtoken', res.data.wxtoken);          
          wx.switchTab({
            url: '../../mine/mine'
          })
        } else {
          wx.showToast({
            // title: '重置失败',
            title: res.data.msg,
            duration: 2000
          })
        }
      }
    })      
  },
  reSendPhoneNum: function () {
    if (currentTime < 0) {
      var that = this
      currentTime = maxTime
      interval = setInterval(function () {
        currentTime--
        that.setData({
          time: currentTime + "s"
        })
        if (currentTime <= 0) {
          currentTime = -1
          clearInterval(interval)
          that.setData({
            time: '获取验证码'
          })
        }
      }, 1000)
    } else {
      wx.showToast({
        title: '短信已发送到您的手机，请稍后重试!',
        icon: 'loading',
        duration: 700
      })
    }
  },
  //发送验证码  
  codeBtn: function (e) {
    // console.log(e)   
    var that = this;
    var mobile = that.data.username;
    console.log(mobile)
    if (mobile == '') {
      wx.showToast({
        title: '请输入手机号！',
        icon: 'none',
      })
    } else {
      wx.request({
        url: app.globalData.url + '/home/Api/issetMobile',
        data: {
          mobile: mobile
        },
        method: 'POST',
        success(res) {
          if (res.data.status == 0) {
            wx.request({
              url: app.globalData.url + '/home/Api/send_validate_code/t=' + Math.random(),
              data: {
                unique_id: 'fsubdfussdbfisbbsjvcsdbf',
                type: 'phone',
                send: mobile,
                scene: 2
              },
              method: 'POST',
              success(res) {
                console.log(res)
                if (res.data.status == 1) {
                  // that.countDown();
                  that.reSendPhoneNum();

                  wx.showToast({
                    title: '发送成功',
                  })
                } else {
                  wx.showToast({
                    title: res.data.msg,
                  })
                }
              }
            })
          } else {
            wx.showToast({
              title: '手机号未注册',
            })
          }
        }
      })
    }
  }, 


})