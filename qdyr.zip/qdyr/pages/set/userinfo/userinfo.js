var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    head_pic: '../../../img/ceshi.jpg',
    nickname: '',
    identity: 1,
    mobile: '',
    sex: '保密'
  },
  //头像
  edit_head_portrait:function(){
    wx.navigateTo({
      url:'../edit_head_portrait/edit_head_portrait',
    })
  },
   company_nam:function(){
    wx.navigateTo({
      url:'../company_nam/company_nam',
    })
  },
  sexxg:function(){
    wx.navigateTo({
      url:'../sexxg/sexxg',
    })
  },
  
  phone:function(){
    wx.navigateTo({
      url:'../phone/phone',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    this.userInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  userInfo: function () {
    var that = this;
    server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      if (res.data.status == 1) {
        var info = res.data.result.info;
        that.setData({
          nickname: info.nickname,
          head_pic: info.head_pic,
          sex: info.sexname,
          mobile: info.mobile,
          identity: info.identity,
        });
      }
    });
  },
})