
// pages/set/security/security.js
var server = require('../../../utils/server');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    id_number: '',
    username: '',
    organization: '',
    identity: 1
  },

  idCard:function(){
    // console.log(this.data.id_number)
    var id_number = this.data.id_number;
    // if(id_number){
    //   wx.showToast({
    //     title: '身份证号已验证',
    //     icon:'none',
    //   })
    // }else{
      wx.navigateTo({
        url: '../dentityid/dentityid',
      })
    // }
    
  
  },

  // 上传营业执照
  name_yyzz: function () {
    wx.navigateTo({
      url: '../yingyezhizhao/yingyezhizhao',
    })
  },

  name_firm:function(){
    
    wx.navigateTo({
      url: '../name_firm/name_firm',
    })
  },
  member_name:function(){
    wx.navigateTo({
      url: '../username/username',
    })
  },
  onLoad: function (options) {
    this.userInfo();
  },
 userInfo: function () {
    var that = this;
   server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res)
      if (res.data.status == 1) {
        var info = res.data.result.info;
        var id_number = res.data.result.info.id_number;
        that.setData({
          username: info.realname,
          organization: info.organization,
          id_number: info.id_number,
          identity: info.identity
        });
      } else if (res.data.stattus == -1) {
        wx.navigateTo({
          url: '../../wode/choice/choice',
        })
      }
    });
  },



})