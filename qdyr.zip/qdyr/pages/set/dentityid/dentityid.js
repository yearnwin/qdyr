var server = require('../../../utils/server');
var app = getApp();
Page({
  data:{
    id_number:'',
    type:1,
    disabled:'',

  },
  onLoad: function () {
    var that = this;
    server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res.data.result);
      var id_number = res.data.result.info.id_number;
      var disabled = 'disabled';
      console.log(disabled)
      if(id_number != ''){
         that.setData({
          id_number: id_number,
          disabled:disabled,
        })

      }
     
    });

  },
    formSubmit:function(e){
      var idCard=e.detail.value.idCard;
      // console.log(e);
    if (idCard == '') {
      wx.showToast({
        title: '请输入身份证',
        icon:'none',
      })
    } else {
      wx.request({
        url: app.globalData.url + '/wxapi/User/identity',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          id_number: idCard,
          type:1,
        },
        method: 'POST',
        success(res) {
          if (res.data.status == 1) {
           console.log(res)
            wx.navigateTo({
              url: '../security/security',
            })
          } else {
            wx.showToast({
              title: res.data.msg
            })
          }
        }
      })
    }
  },
  

  
})