// pages/set/set/set.js
var server = require('../../../utils/server');
var app = getApp();
Page({
//个人信息 
  set_userinfo:function(){
    wx.navigateTo({
      url: '../userinfo/userinfo',
    })
  },
  //地址管理
  edit_address:function(){
    wx.navigateTo({
      url: '../../wode/address_manage/address_manage',
    })
  },
  //安全中心
   security:function(){
    wx.navigateTo({
      url: '../perfect/perfect',
    })
  },
  //隐私
  perfect:function(){
    wx.navigateTo({
      url: '../security/security',
    })
  },

  /**
   * 页面的初始数据
   */
  data: {

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
  onPullDownRefresh:function(){
    
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})