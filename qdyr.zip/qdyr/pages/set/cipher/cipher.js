// pages/set/cipher/cipher.js
var server = require('../../../utils/server');
var app = getApp();
Page({

  formSubmit: function (e) {
    // console.log('form发生了submit事件，携带数据为：', e.detail.value);
    // var newPWD=e.detail.newPWD;
    // console.log(newPWD);
     var oldPwd=e.detail.value.oldPwd;
     var newPwd=e.detail.value.newPwd;
     var newPwdNext=e.detail.value.newPwdNext;
     // oldPwd  newPwd  newPwdNext
      // console.log(company);
    if (newPwd == '') {
      wx.showToast({
        title: '请输入新密码',
      })
      return false;

    } 
     if (newPwdNext == '') {
      wx.showToast({
        title: '请确认密码',
      })
      return false;

    } 
    if (newPwdNext != newPwd) {
      wx.showToast({
        title: '两次密码不一致',
      })
      return false;
      
    } 



    
      wx.request({
        url: app.globalData.url + '/wxapi/User/password',
        data: {
          wxtoken: wx.getStorageSync('wxtoken'),
          oldpassword: oldPwd,
          new_password: newPwd,
          confirm_password: newPwdNext,
        },
        method: 'POST',
        success(res) {
          if (res.data.status == 1) {
           console.log(res)
            wx.navigateTo({
              url: '../../set/set',
            })
          } else {
            wx.showToast({
              title: res.data.msg
            })
          }
        }
      })
  },





  
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },





  
})