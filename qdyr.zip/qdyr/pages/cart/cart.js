var server = require('../../utils/server');
var app = getApp()
Page({
  data: {
    carts: [],
    goodsList: [],
    empty: true,
    minusStatuses: ['disabled', 'disabled', 'normal', 'normal', 'disabled'],
    selectedAllStatus: true,
    total: '',
    url: app.globalData.url,
    p:1

  },

  onLoad: function (option) {
    if (wx.getStorageSync('wxtoken') == '') {
      wx.navigateTo({
        url: '../wode/choice/choice',
      })
      // return;
    }
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        var height = res.windowHeight;
        var height = height - height / 750.0 * 60;
        that.setData({ height: height })
      }
    })
  },
  //马上逛逛
  see: function (e) {
    wx.switchTab({
      url: "../index/index"
    });
  },

  bindMinus: function (e) {
    var index = parseInt(e.currentTarget.dataset.index);
    var num = this.data.carts[index].goods_num;
    // 如果只有1件了，就不允许再减了
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 购物车数据
    var carts = this.data.carts;
    carts[index].goods_num = num;
    // 按钮可用状态
    var minusStatuses = this.data.minusStatuses;
    minusStatuses[index] = minusStatus;
    // 将数值与状态写回
    this.setData({
      carts: carts,
      minusStatuses: minusStatuses
    });
    // update database
    //carts[index].save();
    this.saveNum(carts[index].id, num, carts[index].selected);
    this.sum();
  },
  bindPlus: function (e) {
    var index = parseInt(e.currentTarget.dataset.index);
    var num = this.data.carts[index].goods_num;
    // 自增
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 购物车数据
    var carts = this.data.carts;
    carts[index].goods_num = num;
    // 按钮可用状态
    var minusStatuses = this.data.minusStatuses;
    minusStatuses[index] = minusStatus;
    // 将数值与状态写回
    this.setData({
      carts: carts,
      minusStatuses: minusStatuses
    });
    // update database
    //carts[index].save();
    this.saveNum(carts[index].id, num, carts[index].selected);
    this.sum();
  },
  bindManual: function (e) {
    var index = parseInt(e.currentTarget.dataset.index);
    var carts = this.data.carts;
    var num = e.detail.value;
    carts[index].goods_num = num;
    // 将数值与状态写回
    this.setData({
      carts: carts
    });
    this.saveNum(carts[index].id, num, carts[index].selected);
    this.sum();
  },
  bindCheckbox: function (e) {
    /*绑定点击事件，将checkbox样式改变为选中与非选中*/
    //拿到下标值，以在carts作遍历指示用
    var index = parseInt(e.currentTarget.dataset.index);
    
    //原始的icon状态
    var selected = this.data.carts[index].selected;
    var carts = this.data.carts;
    // 对勾选状态取反
    carts[index].selected = !selected;
    // 写回经点击修改后的数组
    this.setData({
      carts: carts,
    });
    // update database

    this.updataSelect(carts[index].id, carts[index].selected);
    this.sum();
  },
  bindSelectAll: function () {
    // 环境中目前已选状态
    var selectedAllStatus = this.data.selectedAllStatus;
    // 取反操作
    selectedAllStatus = !selectedAllStatus;
    // 购物车数据，关键是处理selected值
    var carts = this.data.carts;
    // 遍历
    for (var i = 0; i < carts.length; i++) {
      carts[i].selected = selectedAllStatus;
      // update selected status to db
    }
    this.setData({
      selectedAllStatus: selectedAllStatus,
      carts: carts,
    });
    this.sum();
    var open_id = app.globalData.openid;
    this.updateAllSelect(open_id, selectedAllStatus);
  },
  bindCheckout: function () {
    var that = this;
    var user_id = getApp().globalData.userInfo.user_id;
    var mobile = getApp().globalData.userInfo.mobile;

    // 遍历取出已勾选的cid
    // var buys = [];
    var cartIds = [];
    for (var i = 0; i < this.data.carts.length; i++) {
      if (this.data.carts[i].selected) {
        // 移动到Buy对象里去
        // cartIds += ',';
        cartIds.push(this.data.carts[i].id);
      }
    }
    if (cartIds.length <= 0) {
      wx.showToast({
        title: '请勾选商品',
        icon: 'success',
        duration: 1000
      })
      return;
    }
    //注释绑定手机--2018年10月11日 16:13:42--空灭道
    // if (!mobile) {
    //   wx.showToast({
    //     title: '请先绑定手机',
    //     icon: 'success',
    //     duration: 1000
    //   })
    //   wx.navigateTo({
    //     url: '../member/mobile/mobile'
    //   });
    //   return;
    // }

    
    wx.navigateTo({
      url: '../other/queren/queren'
    });
  },
  getCarts: function () {
    var minusStatuses = [];
    var that = this;

    // var user_id = "0"

    // user_id = app.globalData.userInfo.user_id

    server.getJSON('/Cart/index/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      // console.log(res)
      var carts = res.data.result.list
      // success
      var goodsList = [];

      if (carts.length != 0)
        that.setData({ empty: false });
      else {
        that.setData({ empty: true });
      }
      var selectedAllStatus = true;
      for (var i = 0; i < carts.length; i++) {
        //var goods = carts[i].get('goods');
        //goodsList[i] = goods;
        //carts[i].selected = true;
        if (carts[i].selected == 1)
          carts[i].selected = true;
        else {
          carts[i].selected = false;
          selectedAllStatus = false;
        }
        minusStatuses[i] = 1;//carts[i].get('quantity') <= 1 ? 'disabled' : 'normal';
      }
      that.setData({
        carts: carts,
        selectedAllStatus: selectedAllStatus,
        //goodsList: goodsList,
        minusStatuses: minusStatuses
      });
      // sum
      that.sum();
    });
  },

  onShow: function () {
    
    // auto login
    this.getCarts();
    return;
    var that = this;
    var user = AV.User.current();
    var query = new AV.Query('Cart');
    var minusStatuses = [];
    query.equalTo('user', user);
    query.include('goods');
    query.find().then(function (carts) {
      // set goods data
      var goodsList = [];
      for (var i = 0; i < carts.length; i++) {
        var goods = carts[i].get('goods');
        goodsList[i] = goods;
        minusStatuses[i] = carts[i].get('quantity') <= 1 ? 'disabled' : 'normal';
      }
      that.setData({
        carts: carts,
        goodsList: goodsList,
        minusStatuses: minusStatuses
      });
      // sum
      that.sum();
    });
  },
  sum: function () {
    var carts = this.data.carts;
    // 计算总金额
    var total = 0;
    for (var i = 0; i < carts.length; i++) {
      if (carts[i].selected) {
        total += carts[i].goods_num * carts[i].member_goods_price;
      }
    }
    var newValue = parseInt(total * 100);
    total = newValue / 100.0;
    // 写回经点击修改后的数组
    this.setData({
      carts: carts,
      total: total
    });
  },
  deleteCart: function (e) {
    var index = parseInt(e.currentTarget.dataset.index)
    var id = this.data.carts[index].id;
    var that = this
    server.getJSON('/Cart/delete/cart_ids/' + id + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      that.getCarts();
    });
  },
  saveNum: function (id, num, selected) {
    var that = this;
    server.getJSON('/Cart/changeNum/id/' + id + "/goods_num/" + num + '/selected/' + selected + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      that.getCarts();
    });
  },
  updataSelect: function (id, selected) {
    if (selected)
      selected = 1;
    else selected = 0;
    server.getJSON('/Cart/AsyncUpdateCart/cart_id/' + id + "/selected/" + selected + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
    });
  },
  updateAllSelect: function (id, selected) {
    if (selected)
      selected = 1;
    else selected = 0;
    server.getJSON('/Cart/updateAllSelect/open_id/' + id + "/selected/" + selected, function (res) {
    });
  },


    //上拉刷新
  //  onReachBottom: function () {
  //         console.log('稍等片刻');
  //           var that = this
  //   setTimeout(() => {
  //        server.getJSON('/Goods/goods_list/id/'+this.data.id+'/p/'+this.data.p,function(res){ 
  //         var len=res.data.result.list.length;
  //         console.log(len);
  //         if(len>0){
  //             that.setData({
  //               goods_list:res.data.result.list,
  //               p:that.data.p+1
  //               });
  //         }
            
  //       })
  //   },3000)



  //   },


    //下拉刷新
  // onPullDownRefresh:function()
  // {
  //   wx.showNavigationBarLoading() //在标题栏中显示加载  
  //   //模拟加载
  //   setTimeout(function()
  //   {
  //     wx.hideNavigationBarLoading() //完成停止加载
  //     wx.stopPullDownRefresh() //停止下拉刷新
  //   },1000);
  // },













})