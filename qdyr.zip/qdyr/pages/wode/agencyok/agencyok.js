// pages/wode/agencyok/agencyok.js
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        top_msg: {},
        order_list:[]
    },
    // 经销商总数
    agency_list:function(){
        wx.navigateTo({
            url: '../agency_list/agency_list?cate_id=' + '1',
        })
    },
    // 当月业绩
    performance1: function () {
        wx.navigateTo({
            url: '../performance/performance1/performance1?cate_id=' + '1',
        })
    },
    // 前两月业绩
    performance2: function () {
        wx.navigateTo({
            url: '../performance/performance2/performance2?cate_id=' + '1',
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        this.mygetdata()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    mygetdata: function () {
        let that=this
        wx.request({
            url: app.globalData.url +'/wxapi/user/county',
            data:{
                wxtoken: wx.getStorageSync('wxtoken')
            },
            method:'GET',
            dataType:'json',
            success(res){
                console.log(res.data)
                that.setData({
                    //userList: res.data.users
                    top_msg:res.data.top_msg,
                    order_list:res.data.order_list,
                })
            },
            fail(err){
                console.log(err)
            }
        })
    },
    // 
    gouserdetail:function(e){
        let user_id=e.currentTarget.dataset.userid;
        console.log('代理页面传给详情页的id：'+user_id);
        wx.navigateTo({
            url: '../userdetail/userdetail?user_id=' + user_id,
        })
    }
})