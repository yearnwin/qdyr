var server = require('../../../utils/server');
var app = getApp();
Page({
    /**
     * 页面的初始数据
     */
    data: {
        address_list: [],
        id: 0,
        goType: 0,
        goods_id: '',
        item_id: '',
        action: '',
        goods_num: '',
        custom_desc: '',
        custom_pic: '',
        send_name: '',
        cus_wx: '',
        pic_length:'',
        cus_phone:'',
        cus_note:'',
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var goType = options.goType;
        // 拼团订单地址选择参数
        var id = options.id;
        console.log(id)
        var is_crate = options.is_crate;
        var group_id = options.group_id;
        var goods_id = options.goods_id;
        var item_id = options.item_id;
        var action = options.action;
        var goods_num = options.goods_num;
        let custom_desc = options.custom_desc;
        let custom_pic = options.custom_pic;
        let send_name = options.send_name;
        let cus_wx = options.cus_wx;
        let pic_length = options.pic_length;
        let cus_phone = options.cus_phone;
        let cus_note = options.cus_note;
        console.log('地址页面接受到的参数：' + goods_id + ':' + item_id + ':' + action + ':' + goods_num + ':' + custom_pic + ':' + custom_desc + ':' + send_name + ':' + cus_wx + ':' + cus_phone + ':' + cus_note)
        if (custom_desc != undefined && custom_pic != undefined) {
            this.setData({
                goType: goType,
                id: id,
                is_crate: is_crate,
                group_id: group_id,
                goods_id: options.goods_id,
                item_id: options.item_id,
                action: options.action,
                goods_num: options.goods_num,
                custom_desc: options.custom_desc,
                custom_pic: options.custom_pic,
                send_name: options.send_name,
                cus_wx: options.cus_wx,
                pic_length: pic_length,
                cus_phone: cus_phone,
                cus_note: cus_note,
            })
        }
        this.getAddress();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */

    //下拉刷新
    onPullDownRefresh: function() {
        wx.showNavigationBarLoading() //在标题栏中显示加载  
        //模拟加载
        setTimeout(function() {
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
        }, 1000);
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    },
    getAddress: function() {
        var that = this;
        server.getJSON('/User/address_list/wxtoken/' + wx.getStorageSync('wxtoken'), function(res) {
            var address_list = res.data.list;
            console.log(res);
            that.setData({
                address_list: address_list
            });
        });
    },
    setAddress: function() {
        wx.redirectTo({
            url: '../../set/edit_address/edit_address?objectId=' + this.data.id + '&goType=' + this.data.goType,
        })
    },
    updateAddress: function(e) {
        var addressId = e.currentTarget.dataset.addressId;
        wx.redirectTo({
            url: '../../set/edit_address/edit_address?objectId=' + addressId + '&goType=' + this.data.goType,
        })
    },
    backQueren: function(e) {
        var that = this;
        var goType = that.data.goType;
        var addressId = e.currentTarget.dataset.addressId;
        var is_default = e.currentTarget.dataset.defaultId;
        let goods_id = this.data.goods_id;
        let item_id = this.data.item_id;
        let action = this.data.action;
        let goods_num = this.data.goods_num;
        let custom_pic = this.data.custom_pic;
        let custom_desc = this.data.custom_desc;
        let send_name = this.data.send_name;
        let cus_wx = this.data.cus_wx;
        let pic_length = this.data.pic_length;
        let cus_phone = this.data.cus_phone;
        let cus_note = this.data.cus_note;
        console.log('地址页面发送到购买页的参数：' + goods_id + ':' + item_id + ':' + action + ':' + goods_num + ':' + custom_pic + ':' + custom_desc + ':' + send_name + ':' + cus_wx + ':' + cus_phone + ':' + cus_note)
        if (goType == 1) {
            if (is_default == 1) {
                wx.redirectTo({
                    url: '../../other/queren/queren?goods_id=' + goods_id + '&item_id=' + item_id + '&action=' + action + '&goods_num=' + goods_num + '&custom_pic=' + custom_pic + '&custom_desc=' + custom_desc + '&cus_wx=' + cus_wx + '&send_name=' + send_name + '&pic_length=' + pic_length + '&cus_phone=' + cus_phone + '&cus_note=' + cus_note
                })
            } else {
                server.getJSON('/User/set_default/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + addressId, function(res) {
                    wx.redirectTo({
                        url: '../../other/queren/queren?goods_id=' + goods_id + '&item_id=' + item_id + '&action=' + action + '&goods_num=' + goods_num + '&custom_pic=' + custom_pic + '&custom_desc=' + custom_desc + '&cus_wx=' + cus_wx + '&send_name=' + send_name + '&pic_length=' + pic_length + '&cus_phone=' + cus_phone + '&cus_note=' + cus_note,
                    })
                })
            }
        } else if (goType == 2) {
            if (is_default == 1) {
                wx.redirectTo({
                    url: '../../collage/queren/queren?id=' + that.data.id + '&is_crate=' + that.data.is_crate + '&group_id=' + that.data.group_id,
                })
            } else {
                server.getJSON('/User/set_default/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + addressId, function(res) {
                    wx.redirectTo({
                        url: '../../collage/queren/queren?id=' + that.data.id + '&is_crate=' + that.data.is_crate + '&group_id=' + that.data.group_id,
                    })
                })
            }
        }
    },
    // 删除地址
    delAddress: function(e) {
        var that = this;
        var id = e.currentTarget.dataset.addressId;
        wx.showModal({
            title: '提示',
            content: '是否删除',
            success: function(res) {
                if (res.confirm) {
                    // console.log('confirm确定');
                    server.getJSON('/User/del_address/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + id, function(res) {
                        if (res.data.status == 1) {
                            that.getAddress();
                        } else {
                            wx.showToast({
                                title: res.data.msg,
                            })
                        }
                    })
                }
            }
        })
    },
})