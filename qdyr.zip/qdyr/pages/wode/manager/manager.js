// pages/wode/manager/manager.js
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        region: [''],
        userName: '',
        identityCard: '',
        mobile: '',
    },
    // 地址
    bindRegionChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region: e.detail.value
        })
    },
    // 姓名
    userNameInput: function (e) {
        console.log('姓名：', e.detail.value)
        this.setData({
            userName: e.detail.value
        })
    },
    // 电话
    phoneIdentityInput: function (e) {
        console.log('电话：', e.detail.value)
        this.setData({
            mobile: e.detail.value
        })
    },
    // 身份证
    userIdentityInput: function (e) {
        console.log('身份证号：', e.detail.value)
        this.setData({
            identityCard: e.detail.value
        })
    },
    // 提交
    formsubmit: function () {
        let that = this;
        console.log(this.data.region, this.data.userName, this.data.identityCard, app.globalData.url)
        let username = that.data.userName;
        let idnumber = that.data.identityCard;
        let county = that.data.region;
        let mobile = that.data.mobile;
        let idcardReg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
        if (username === '') {
            wx.showToast({
                title: '请填写姓名！',
            })
            return;
        }
        if (!idcardReg.test(idnumber)) {
            wx.showToast({
                title: '请填写身份证号！',
            })
            return;
        }
        if (mobile === '') {
            wx.showToast({
                title: '请填写电话！',
            })
            return;
        }
        if (county === '') {
            wx.showToast({
                title: '请选择地址！',
            })
            return;
        }
        
        wx.request({
            url: app.globalData.url + '/wxapi/user/managers',
            data: {
                username: username,
                idnumber: idnumber,
                county: county,
                mobile: mobile,
                cate_id: 2,
                wxtoken: wx.getStorageSync('wxtoken')
            },
            method: 'POST',
            dataType: 'json',
            success(res) {
                console.log(res.data)
                if(res.data.status===1){
                    wx.showToast({
                        title: '成功递交申请',
                        duration: 2000
                    })
                    wx.switchTab({
                        url: '../../index/index'
                    })
                } else if (res.data.status === 2){
                    wx.showToast({
                        title: '审核中',
                    })
                }
            },
            fail(err) {
                console.log(err)
            }
        })
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})