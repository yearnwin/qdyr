// pages/wode/pingjia/pingjia.js
var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    files: [],
    showTopTips: false,

    order_goods: [],
    order_id: '',
    goods_id: '',
    url: app.globalData.url,
    content: '',
    start: 0,
    noname: 0,
    upimage1: '',
    upimage2: '',
    upimage3: '',
    imgnum: 1,
    rec_id: '',
    thumb: ''
  },

  // 评星
  starClick: function (e) {
    console.log(e.currentTarget.id);
    var index = parseInt(e.currentTarget.id);
    var start = e.currentTarget.dataset.starLevel;
    console.log(start);
    this.setData({
      curStarIndex: index,
      start: start
    });
  },
  // 匿名
  checkboxChange: function (e) {
    var noname = e.currentTarget.dataset.noName;
    console.log(noname)
    this.setData({
      noname: noname
    });
  },

  // 上传图片
  chooseImage: function (e) {
    var that = this;
    var imgnum = e.currentTarget.dataset.imgNum;
    wx.chooseImage({
      success: function (res) {
        wx.getImageInfo({
          src: res.tempFilePaths[0],
          success: function (res) {
            that.setData({
              thumb: res.path
            })
          }
        })
      }
    })
    // wx.chooseImage({
    //   sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
    //   sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
    //   count: 3,
    //   success: function (res) {
    //     // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
    //     that.setData({
    //       files: that.data.files.concat(res.tempFilePaths),
    //       imgnum: imgnum + 1
    //     });
    //     console.log(that.data);
    //   }
    // })
  },
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.id, // 当前显示图片的http链接
      urls: this.data.files // 需要预览的图片http链接列表
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var recId = options.recId;
    this.setData({
      rec_id: recId
    });
    this.getInfo(recId);
  },
  // 订单商品
  getInfo: function (recId) {
    var that = this;
    server.getJSON('/Order/add_comment/wxtoken/' + wx.getStorageSync('wxtoken') + '/rec_id/' + recId, function (res) {
      if (res.data.status == 1) {
        var order_goods = res.data.order_goods;
        that.setData({
          order_goods: order_goods,
          order_id: order_goods.order_id,
          goods_id: order_goods.goods_id
        })
      }
    })
  },
  // 评价内容
  blur: function (e) {
    var content = e.detail.value;
    this.setData({
      content: content
    })
  },
  // 提交评价
  submitComment: function () {
    var that =this;
    var thumb = that.data.thumb;
    var content = that.data.content;
    var star = that.data.start;
    var noname = that.data.noname;
    var goods_id = that.data.goods_id;
    var order_id = that.data.order_id;
    // console.log(files.length)
    // if (files.length > 0) {
    //   var upimage1 = files[0];
    //   if (files.length == 2) {
    //     var upimage2 = files[1];
    //   }
    //   if (files.length == 3) {
    //     var upimage2 = files[1];
    //     var upimage3 = files[2];
    //   }
    //   that.setData({
    //     upimage1: upimage1,
    //     upimage2: upimage2,
    //     upimage3: upimage3,
    //   })
    // }
    if (content == '') {
      wx.showToast({
        title: '请填写评价！',
      })
      return;
    }
    if (star == 0) {
      wx.showToast({
        title: '请选择评星！',
      })
      return;
    }
    wx.uploadFile({
      url: app.globalData.url + '/wxapi/Order/add_comment/wxtoken/' + wx.getStorageSync('wxtoken') + '/goods_id/' + goods_id + '/order_id/' + order_id + '/content/' + content + '/rec_id/' + that.data.rec_id + '/service_rank/' + star + '/hide_username/' + noname,
      filePath: thumb,
      name: 'image1',
      success(res) {
        wx.showToast({
          title: '已评价',
        })
        wx.navigateTo({
          url: '../mydingdan/mydingdan?id=0',
        })
      },
      fail(res) {
        wx.showToast({
          title: '请选择图片',
        })
      }
      
    })
    // wx.request({
    //   url: app.globalData.url + '/wxapi/Order/add_comment',
    //   data:{
    //     wxtoken: wx.getStorageSync('wxtoken'),
    //     rec_id: that.data.rec_id,
    //     goods_id: that.data.goods_id,
    //     order_id: that.data.order_id,
    //     content: that.data.content,
    //     service_rank: star,
    //     hide_username: that.data.noname,
    //     image1: that.data.upimage1,
    //     image2: that.data.upimage2, 
    //     image3: that.data.upimage3
    //   },
    //   method: 'POST',
    //   success: function (res) {
    //     if(res.data.status == 1){
        
    //     }
    //     wx.showToast({
    //       title: '已评论',
    //     })
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
  onPullDownRefresh:function(){
    
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})