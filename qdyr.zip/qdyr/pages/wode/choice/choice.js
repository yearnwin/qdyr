// pages/wode/choice/choice.js
var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: ''
  },
  onLoad: function () { 
    // 查看是否授权
    // wx.getSetting({
    //   success(res) {
    //     if (res.authSetting['scope.userInfo']) {
    //       // 已经授权，可以直接调用 getUserInfo 获取头像昵称
    //       wx.getUserInfo({
    //         success: function (res) {
    //           console.log(res)
    //           // this.setData({
    //           //   userInfo:res.userInfo,
    //           // });
    //           // app.globalData.userInfo.nickName = userInfo.nickName;
    //           // app.globalData.userInfo.avatarUrl = userInfo.avatarUrl;
    //         }
    //       })
    //     }
    //   }
    // })
  },

  // 绑定关系
  // bindCommission: function () {
  //   server.getJSON('/User/bind_first_leader/wxtoken/' + wx.getStorageSync('wxtoken') + '/first_leader/' + wx.getStorageSync('app_send_user_id'), function (res) {
  //     // if (res.data.status != 1) {
  //     //   wx.showToast({
  //     //     title: '请登录后操作',
  //     //   })
  //     // }
  //   })
  // },

  bindGetUserInfo: function (e) {
    var that = this;
    //此处授权得到userInfo
    if (e.detail.userInfo) {
      var userInfo = e.detail.userInfo;
      console.log(userInfo);
      that.setData({
        userInfo: e.detail.userInfo,
      });
      console.log(app.globalData.openid);
      console.log(app.globalData.unionId)
      wx.request({
        url: app.globalData.url + '/wxapi/LoginApi/new_login',
        data: {
          openid: app.globalData.openid,
          unionid: app.globalData.unionId,
          oauth: 'wxxcx',
          nickname: userInfo.nickName,
          head_pic: userInfo.avatarUrl
        },
        method: 'POST',
        success: function (res) {
          if (res.data.status == 1) {
            if (res.data.code == 200) {
              // app.globalData.login = true;
              wx.navigateTo({
                url: '../../other/bind/bind?id=' + res.data.id,
              })
            } else if (res.data.code == 100) {
              // app.globalData.login = true;//登录成功
              wx.setStorageSync('app_send_user_id', '');
              wx.setStorageSync('wxtoken', res.data.result.wxtoken);//緩存--wxtoken
              wx.setStorageSync('login', true);
              wx.navigateBack({
                delta: 1
              })  
              // wx.switchTab({
              //   url: '../../mine/mine',
              // })
            }
          }
        }
      })
    }
  },
 
  qiye: function (e) {
    wx.navigateTo({
      url: '../qiye/qiye'
    })
  },
  shouji: function (e) {
    wx.navigateTo({
      url: '../shouji/shouji'
    })
  },
  register:function(e){
     wx.navigateTo({
      url: '../huiyuan_zc/huiyuan_zc'
    })
  },
})