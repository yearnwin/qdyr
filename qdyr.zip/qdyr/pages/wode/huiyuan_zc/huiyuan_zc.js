var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
var maxTime = 60
var interval = null
var currentTime = -1 //倒计时的事件（单位：s
Page({
    data: {
        current: 0,
        tabStates: [true, false, false],
        tabClasss: ["text-select", "text-normal", "text-normal"],
        galleryHeight: getApp().screenWidth,
        tab: 0,
        textStates: ["view-btns-text-normal", "view-btns-text-select"],
        article: '<div>我是HTML代码</div>',
        mailCode: "发送验证码",
        boolean: true,
        isChecked: false, phone: '',
        phoneTip: '',
        keyCode: '',
        keyCodeTip: '',
        userName: '',
        userNameTip: '',
        userPassword: '',
        userPasswords: '',
        userPasswordTip: '',
        next: '',
        code: '',
        info: '',
        userPasswordTips: '',
        verify_code: '',
        phoneTip: '',
        unique: 'fsubdfussdbfisbbsjvcsdbf',
        invite: '',
        time: '获取验证码',
        region: ['请选择'],
    },

    //手机号  
    phoneInput: function (e) {
        let username = e.detail.value;
        let myreg = /^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,3,6,7,8]{1}\d{8}$|^18[\d]{9}$/;
        if (username.length == 0) {
            this.setData({
                phoneTip: '手机号不能为空'
            })
        } else if (!myreg.test(username)) {
            this.setData({
                phoneTip: '请检查您的手机号是否有误'
            })
        } else {
            this.setData({
                phoneTip: '',
                username: username,
                boolean: false
            })
        }
    },
    // 地址
    bindRegionChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region: e.detail.value
        })
    },

    //注册  
    oLogin: function (e) {
        console.log(e)

        var that = this;

        var region = that.data.region;
        var unique = 'fsubdfussdbfisbbsjvcsdbf';
        var username = e.detail.value.phone;
        var code = e.detail.value.code;
        var password = e.detail.value.password;
        var password2 = e.detail.value.password2;
        console.log(region[0]);
        // let avatarUrl = wx.getStorageSync('avatarUrl'); 
        
        if (username == '') {
            wx.showToast({
                title: '请输入手机号',
                icon: 'none',
            });
            return false;
        }
        var myreg = /^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,3,6,7,8]{1}\d{8}$|^18[\d]{9}$/;

        if (!myreg.test(username)) {
            wx.showToast({
                title: '手机号格式不正确',
                icon: 'none',
            });
            return false;
        }
        if (code == '') {
            wx.showToast({
                title: '请输入验证码',
                icon: 'none',

            });
            return false;
        }
        if (password == '') {
            wx.showToast({
                title: '密码不能为空',
                icon: 'none',

            });
            return false;
        }
        if (password2 == '') {
            wx.showToast({
                title: '请输入确认密码',
                icon: 'none',

            });
            return false;
        }
        if (password != password2) {
            wx.showToast({
                title: '确认密码不一致',
                icon: 'none',

            });
            return false;
        }
        if (region == '请选择') {
            wx.showToast({
                title: '请选择地址',
                icon: 'none',
            });
            return false;
        }
        wx.request({
            url: app.globalData.url + '/wxapi/LoginApi/reg',
            data: { 
                mobile_code: code, 
                username: username, 
                password: password, 
                password2: password2, 
                unique: unique, 
                first_leader: wx.getStorageSync('app_send_user_id'),
                region: region
            },
            success: res => {
                //成功的话直接跳转到个人中心     
                var oStatus = res.data.status;
                var info = res.data.info;
                if (oStatus == 1) {
                    // var session_id = res.data.session_id;         
                    // wx.setStorageSync('session_id', session_id);  
                    wx.setStorageSync('wxtoken', res.data.result.wxtoken);
                    wx.setStorageSync('app_send_user_id', '');
                    wx.showToast({
                        title: '注册成功',
                        duration: 2000
                    })
                    wx.navigateBack({
                        delta: 2
                    })
                    // wx.switchTab({            
                    //   url: '../../mine/mine?username=' + username         
                    // })        
                } else {
                    wx.showToast({
                        title: '注册失败',
                        duration: 2000,
                        icon: 'none'
                    })
                }
            }
        })
    },
    reSendPhoneNum: function () {
        if (currentTime < 0) {
            var that = this
            currentTime = maxTime
            interval = setInterval(function () {
                currentTime--
                that.setData({
                    time: currentTime + "s"
                })
                if (currentTime <= 0) {
                    currentTime = -1
                    clearInterval(interval)
                    that.setData({
                        time: '获取验证码'
                    })
                }
            }, 1000)
        } else {
            wx.showToast({
                title: '短信已发送到您的手机，请稍后重试!',
                icon: 'loading',
                duration: 700
            })
        }
    },
    //发送验证码  
    codeBtn: function (e) {
        var that = this;
        var mobile = that.data.username;
        if (mobile == '') {
            wx.showToast({
                title: '请输入手机号！',
                icon: 'none',
            })
        } else {
            wx.request({
                url: app.globalData.url + '/home/Api/issetMobile',
                data: {
                    mobile: mobile
                },
                method: 'POST',
                success(res) {
                    if (res.data.status == 1) {
                        wx.request({
                            url: app.globalData.url + '/home/Api/send_validate_code/t=' + Math.random(),
                            data: {
                                // unique_id: that.data.token,
                                unique_id: that.data.unique,
                                type: 'mobile',
                                send: mobile,
                                scene: 6
                            },
                            method: 'POST',
                            success(res) {
                                if (res.data.status == 1) {
                                    console.log(res.data.msg);
                                    that.reSendPhoneNum();
                                    wx.showToast({
                                        title: '发送成功',
                                    })
                                } else {
                                    console.log(res.msg);
                                    wx.showToast({
                                        title: res.data.msg,
                                    })
                                }
                            }
                        })
                    } else {
                        wx.showToast({
                            title: res.data.msg,
                        })
                    }
                }
            })
        }
    },
    emailInput: function (e) {
        let username = e.detail.value;
        let myreg = /^([a-za-z0-9]+[_|_|.]?)*[a-za-z0-9]+@([a-za-z0-9]+[_|_|.]?)*[a-za-z0-9]+.[a-za-z]{2,3}$/;
        if (username.length == 0) {
            this.setData({
                emailTip: '手机号不能为空'
            })
        } else if (!myreg.test(username)) {
            this.setData({
                emailTip: '请检查您的邮箱是否有误'
            })
        } else {
            this.setData({
                emailTip: '',
                username: username,
                boolean: false
            })
        }
    },
    //验证码  
    nameInput: function (e) {
        let nickname = e.detail.value;
        if (nickname.length == 0) {
            this.setData({
                nameTip: '验证码不能为空'
            })
        } else {
            this.setData({
                nameTip: '',
                nickname: nickname,
            })
        }
    },

    //用户密码  
    passInput: function (e) {
        let password = e.detail.value;
        if (password.length < 6 || password.length > 16) {
            this.setData({
                passTip: '密码长度为6-16位'
            })
        } else {
            this.setData({
                passTip: '',
                password: password
            })
        }
    },
    pass2Input: function (e) {
        let password2 = e.detail.value;
        if (password2.length < 6 || password2.length > 16) {
            this.setData({
                pass2Tip: '密码长度为6-16位'
            })
        } else {
            this.setData({
                passTip: '',
                password2: password2
            })
        }
    },


    // 企业注册
    reg: function (e) {
        console.log(e)
        var that = this;


        var unique = 'fsubdfussdbfisbbsjvcsdbf';
        var username = e.detail.value.email;
        var nickname = e.detail.value.nickname;
        var password = e.detail.value.password;
        var password2 = e.detail.value.password2;
        var invite = e.detail.value.invite;

        // let avatarUrl = wx.getStorageSync('avatarUrl'); 
        if (nickname == '') {
            wx.showToast({
                title: '请输入公司名称',
                icon: 'none',
            });
            return false;
        }
        if (username == '') {
            wx.showToast({
                title: '请输入邮箱',
                icon: 'none',
            });
            return false;
        }

        if (password == '') {
            wx.showToast({
                title: '密码不能为空',
                icon: 'none',

            });
            return false;
        }
        if (password2 == '') {
            wx.showToast({
                title: '请输入确认密码',
                icon: 'none',

            });
            return false;
        }
        if (password != password2) {
            wx.showToast({
                title: '确认密码不一致',
                icon: 'none',

            });
            return false;
        }

        wx.request({
            url: app.globalData.url + '/wxapi/LoginApi/reg_company',
            data: { username: username, nickname: nickname, password: password, password2: password2, invite: invite, first_leader: wx.getStorageSync('app_send_user_id') },
            success: res => {
                //成功的话直接跳转到个人中心       
                var oStatus = res.data.status;
                console.log(res)
                var info = res.data.info;
                if (oStatus == 1) {
                    // var session_id = res.data.session_id;         
                    // wx.setStorageSync('session_id', session_id); 
                    wx.setStorageSync('wxtoken', res.data.result.wxtoken);
                    wx.setStorageSync('app_send_user_id', '');
                    wx.showToast({
                        title: res.data.msg,
                        duration: 2000
                    })
                    wx.navigateBack({
                        delta: 2
                    })

                    // wx.switchTab({            
                    //   url: '../../mine/mine?username=' + username         
                    // })        
                } else {
                    // console.log(1)         
                    // info: res.data.info
                    wx.showToast({
                        title: '请确认邮箱',
                        duration: 2000
                    })
                }
            }
        })
    },

    /**   * 生命周期函数--监听页面加载   */
    onLoad: function (options) {
        // console.log(options)
        var that = this;
        // this.setData({      
        // //把读取出来的数据存储到页面的数据data中     
        // verify_code: options.code    
        // })  
    },


    tabClick: function (e) {
        var index = e.currentTarget.dataset.index
        var classs = ["text-normal", "text-normal", "text-normal"]
        classs[index] = "text-select"
        this.setData({ tabClasss: classs, tab: index })
    },
});