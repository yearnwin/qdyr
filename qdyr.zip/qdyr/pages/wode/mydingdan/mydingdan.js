var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置
var server = require('../../../utils/server');
var app = getApp();
var success = require('../../../utils/util');
var order_status = '';
var p = 1;
Page({
  data: {
    tabs: ["全部订单", "待付款", "待发货", "已发货", "已完成"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    status_list: '',
    order_list: 0,
    goods: '',
    goods_list: '',
    url: app.globalData.url,
    order_status_desc: '',
    id: 0,
  },


  //加载全部订单
  onLoad: function (options) {
    var that = this;
    var cateId = options.id;
    if (cateId == 1) {
      order_status = 'WAITPAY';
    } else if (cateId == 2) {
      order_status = 'WAITSEND';
    } else if (cateId == 3) {
      order_status = 'WAITRECEIVE';
    }
    this.statusOrderList(order_status);
    that.setData({
      activeIndex: cateId
    });
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
          sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        });
      }
    });
  },
  
  //切换按钮
  tabClick: function (e) {
    var that = this
    var activeIndex = e.currentTarget.id;
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    });
    if (activeIndex == 1) {
      order_status = 'WAITPAY';
    } else if (activeIndex == 2) {
      order_status = 'WAITSEND';
    } else if (activeIndex == 3) {
      order_status = 'WAITRECEIVE';
    } else if (activeIndex == 4) {
      order_status = 'FINISH';
    } else if (activeIndex == 0) {
      order_status = '';
    }
    this.setData({
      p: 1
    })
    this.statusOrderList();

  },

  //跳转订单详情
  showDetail: function (e) {
    var goodsId = e.currentTarget.dataset.orderId;
    wx.navigateTo({
      url: "../orderdetails/orderdetails?order_id=" + goodsId
    });
  },

  //定单状态请求  后端程序
  statusOrderList: function () {
    var that = this
    var uid = app.globalData.unionId;
    server.getJSON('/Order/order_list/wxtoken/' + wx.getStorageSync('wxtoken') + '/type/' + order_status, function (res) {
      var goods_list = res.data.list;
      var gg = res.data.list.goods_list;
      that.setData({
        goods_list: goods_list
      });

    });

  },

  // 提醒发货
  callSend: function (e) {
    var that = this;
    var order_id = e.currentTarget.dataset.orderId;
    server.getJSON('/Order/order_call/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + order_id, function (res) {
      if (res.data.status == 1) {
        wx.showToast({
          title: '休息中',
        })
      } else {
        wx.showToast({
          title: '已提醒',
        })
      }
    })
  },

  // 确认收货
  makeSure: function (e) {
    var that = this;
    var order_id = e.currentTarget.dataset.orderId;
    server.getJSON('/Order/order_confirm/wxtoken/' + wx.getStorageSync('wxtoken') + '/id/' + order_id, function (res) {
      if (res.data.status == 1) {
        that.statusOrderList();
      } else {
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  // 再来一单
  orderagent: function (e) {
    var order_id = e.currentTarget.dataset.orderId;
    server.getJSON('/Cart/repeat_order/id/' + order_id + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      if (res.data.status == -1) {
        wx.showToast({
          title: res.data.msg,
        })
      } else {
        wx.switchTab({
          url: '../../cart/cart?id=' + order_id,
        })
      }
    });
  },
  // 立即购买
  buyNow: function (e) {
    var order_id = e.currentTarget.dataset.orderId;
    var order_amount = e.currentTarget.dataset.orderAmount;
    wx.navigateTo({
      url: '../../other/pay/pay?order_id=' + order_id + '&amount=' + order_amount
    })
  },

  //取消订单
  cancel_order: function (res) {
    var order_id = res.currentTarget.dataset.orderId;
    var that = this
    wx.showModal({
      title: '确认取消订单',
      content: '是否取消此订单',
      success: function (res) {
        if (res.confirm) {
          server.getJSON('/Order/cancel_order/id/' + order_id + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
            if (res.data.status == 1) {
              that.statusOrderList();
              that.setData({
                activeIndex: 1
              })
            }
            wx.showToast({
              title: '已取消',
            })
            that.statusOrderList();

          });
        } else if (res.cancel) {
          wx.showToast({
            title: '已取消',
          })

        }
      }
    })
  },

  //上拉刷新
  // onReachBottom: function () {
  //   console.log('上拉加载')
  //   wx.showToast({
  //     title: '上拉加载',
  //   })
  //   var that = this
  //   wx.showNavigationBarLoading() //在标题栏中显示加载  
  //   //模拟加载
  //   wx.showToast({
  //     title: '加载中...',
  //     icon: 'loading'
  //   })
  //   setTimeout(function () {
  //     wx.hideNavigationBarLoading() //完成停止加载
  //     wx.stopPullDownRefresh() //停止下拉刷新
  //   }, 1000);

  //   var p = that.data.p + 1;
  //   that.setData({
  //     p: p
  //   })

  //   server.getJSON('/Order/order_list/wxtoken/' + wx.getStorageSync('wxtoken') + '/type/' + order_status + '/page/' + p, function (res) {
  //     var gg = res.data.list;
  //     if (gg.length > 0) {
  //       that.setData({
  //         goods_list: that.data.goods_list.concat(gg)
  //       });
  //     }
  //   });
  // },

  // onPullDownRefresh: function () {
  //   console.log('上拉加载')
  //   wx.showToast({
  //     title: '上拉加载',
  //   })
  //   var that = this
  //   wx.showNavigationBarLoading() //在标题栏中显示加载  
  //   //模拟加载
  //   wx.showToast({
  //     title: '加载中...',
  //     icon: 'loading'
  //   })
  //   setTimeout(function () {
  //     wx.hideNavigationBarLoading() //完成停止加载
  //     wx.stopPullDownRefresh() //停止下拉刷新
  //   }, 1000);

  //   var p = that.data.p + 1;
  //   that.setData({
  //     p: p
  //   })

  //   server.getJSON('/Order/order_list/wxtoken/' + wx.getStorageSync('wxtoken') + '/type/' + order_status + '/page/' + p, function (res) {
  //     var gg = res.data.list;
  //     if (gg.length > 0) {
  //       that.setData({
  //         goods_list: that.data.goods_list.concat(gg)
  //       });
  //     }
  //   });
  // }
})