// pages/wode/userdetail/userdetail.js
var app = getApp();
import {
    http
} from '../../../utils/http.js'
Page({

    /**
     * 页面的初始数据
     */
    data: {
        user_id: '',
        order: [],
        summoney: '',
        user: '',
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let user_id = options.user_id;
        console.log('详情页接收到的id:' + user_id);
        this.setData({
            user_id: user_id,
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        this.getorderdetail()
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    },
    getorderdetail: function() {
        let user_id = this.data.user_id;
        let that = this;
        // 使用http.js中的方法发送请求
        http('GET', '/wxapi/user/countyinfo', {user_id: user_id}).then(res => {
            console.log(res)
            let order = res.data.order;
            let summoney = res.data.summoney;
            let user = res.data.user;
            that.setData({
                order,
                summoney,
                user,
            })
        })
        // wx.request({
        //     url: app.globalData.url +'/wxapi/user/countyinfo',
        //     data:{
        //         user_id:user_id,
        //         wxtoken: wx.getStorageSync('wxtoken'),
        //     },
        //     method:'GET',
        //     dataType:'json',
        //     success(res){
        //         console.log(res)
        //         let order = res.data.order;
        //         let summoney = res.data.summoney;
        //         let user = res.data.user;
        //         that.setData({
        //             order,
        //             summoney,
        //             user,
        //         })
        //     },
        //     fail(err){
        //         console.log(err)
        //     }
        // })
    }
})