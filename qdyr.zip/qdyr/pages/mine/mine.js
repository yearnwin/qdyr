//index.js
//获取应用实例
var server = require('../../utils/server');
var app = getApp();
Page({
    data: {
        // userInfo: app.globalData.userInfo,

        head_pic: '../../img/ceshi.jpg',
        nickname: '去登陆',
        user_money: 0,
        pay_point: 0,
        coupon_count: 0,
        waitPay: 0,
        waitReceive: 0,
        uncomment_count: 0,
        return_count: 0,
        waitSend: 0,
        user_cash: 0,
        identity: 0,
        partner: 0,
        levelimg: '../../image/wd_jdt.png',
        like: [],
        url: app.globalData.url,
        level: '',
        login: false,
        onteam: 0,
        is_county: 0,
        level: '',
        is_managers: 0,
        agency_status: '',
        manager_status: '',
    },
    onLoad: function(options) {
        console.log(wx.getStorageSync('wxtoken'));
    },
    onShow: function() {
        this.userInfo();
        this.doYouLike();
        this.applyjd();
    },
    applyjd: function() {
        let that = this;
        wx.request({
            url: app.globalData.url + '/wxapi/user/agency',
            data: {
                // username: username,
                // idnumber: idnumber,
                // county: county,
                wxtoken: wx.getStorageSync('wxtoken')
            },
            method: 'POST',
            dataType: 'json',
            success(res) {
                //console.log(res.data.status)
                if (res.data.status == 2) {
                    that.setData({
                        agency_status: res.data.status
                    })
                }
            }
        })
        wx.request({
            url: app.globalData.url + '/wxapi/user/managersok',
            data: {
                // username: username,
                // idnumber: idnumber,
                // county: county,
                wxtoken: wx.getStorageSync('wxtoken')
            },
            method: 'POST',
            dataType: 'json',
            success(res) {
                //console.log(res.data.status)
                if (res.data.status == 2) {
                    that.setData({
                        manager_status: res.data.status
                    })
                }
            }
        })
    },
    userInfo: function() {
        var that = this;
        server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function(res) {
            //console.log(res.data.result.info.is_managers)
            if (res.data.status == 1) {
                var info = res.data.result.info;
                var count = res.data.result.count;
                var couponList = res.data.result.couponList;
                var visit = res.data.result.visit;
                wx.setStorageSync('level', info.level); //缓存等级
                wx.setStorageSync('login', true);   //缓存登录状态
                that.setData({
                    nickname: info.nickname,
                    head_pic: info.head_pic,
                    coupon_count: info.coupon_count,
                    pay_point: info.pay_points,
                    user_money: info.user_money,
                    user_cash: info.user_cash,
                    waitPay: info.waitPay,
                    waitSend: info.waitSend,
                    waitReceive: info.waitReceive,
                    return_count: info.return_count,
                    uncomment_count: info.uncomment_count,
                    identity: info.identity,
                    partner: info.partner,
                    levelimg: info.levelimg,
                    level: info.level,
                    login: true,
                    onteam: info.onteam,
                    is_county: info.is_county,
                    collect: count,
                    visit: visit,
                    couponList: couponList,
                    is_managers: info.is_managers
                });
            } else if (res.data.status == -1) {
                wx.setStorageSync('login', false);   //缓存登录状态
                that.setData({
                    head_pic: '../../img/ceshi.jpg',
                    nickname: '去登陆',
                    user_money: 0,
                    pay_point: 0,
                    coupon_count: 0,
                    waitPay: 0,
                    waitReceive: 0,
                    uncomment_count: 0,
                    return_count: 0,
                    waitSend: 0,
                    user_cash: 0,
                    identity: 0,
                    partner: 0,
                    levelimg: '../../image/wd_jdt.png',
                    like: [],
                    url: app.globalData.url,
                    login: false,
                    onteam: 0
                })
            }
        });
    },
    applyagency: function() {
        let that = this;
        if (that.data.login) {
            if (that.data.agency_status == 2) {
                wx.showToast({
                    title: '审核中',
                    duration: 2000
                })
            } else {
                wx.navigateTo({
                    url: '../wode/agency/agency',
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    applymanager: function() {
        let that = this;
        if (that.data.login) {
            if (that.data.manager_status == 2) {
                wx.showToast({
                    title: '审核中',
                    duration: 2000
                })
            } else {
                wx.navigateTo({
                    url: '../wode/manager/manager',
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    gohtml: function (e) {
        wx.navigateTo({
            url: '../gohtml/gohtml',
        })
    },
    // 个人资料
    gopersonal: function() {
        let that = this;
        if (that.data.login) {
            wx.navigateTo({
                url: '../set/userinfo/userinfo',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 猜你喜欢
    doYouLike: function() {
        var that = this;
        server.getJSON('/loginApi/doyoulike', function(res) {
            var like = res.data.result.list;
            that.setData({
                like: like
            });
        });
    },
    showDetail: function(e) {
        var goodsId = e.currentTarget.dataset.goodsId;
        wx.navigateTo({
            url: "../goods/details/details?objectId=" + goodsId
        });
    },
    doLogin: function() {
        wx.navigateTo({
            url: '../wode/choice/choice'
        })
    },
    //事件处理函数
    // 优惠券
    couponList: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/coupon/coupon'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }

    },
    // 现金券--奖励金
    credit: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/yongjin/yongjin'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 小金库
    cash: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../wode/cash/cash'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 积分
    integralmx: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/integralmx/integralmx'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 拍档
    panter: function() {
        var partner = this.data.partner;
        if (this.data.login == true) {
            if (partner == 1) {
                wx.showToast({
                    title: '您已经是拍档了',
                })
            } else {
                wx.navigateTo({
                    url: '../set/chengwei/chengwei'
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 商超采购
    mallBuy: function() {
        wx.navigateTo({
            url: '../goods/mall/mall'
        })
    },
    // 大宗采购
    buyCenter: function() {
        wx.navigateTo({
            url: '../goods/buy_center/buy_center'
        })
    },
    // 领券中心
    couponCenter: function() {
        wx.navigateTo({
            url: '../other/collar/collar'
        })
    },
    shoucang: function(e) {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../goods/collect/collect'
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    visit: function(e) {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../goods/visit/visit',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    erweima: function(e) {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/erweima/erweima',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },

    distribution: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../wode/distribution/distribution',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },

    myset: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../set/set/set',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },


    collar: function() {
        wx.navigateTo({
            url: '../other/collar/collar',
        })
    },
    kefu: function() {
        wx.navigateTo({
            url: '../other/kefu/kefu',
        })
    },

    //订单处理
    mydingdan: function(e) {
        var id = e.currentTarget.dataset.status;
        if (this.data.login == true) {
            if (id == 4) {
                //评价页
                wx.navigateTo({

                    url: '../goods/comment/comment',
                })
            } else {
                wx.navigateTo({
                    url: '../wode/mydingdan/mydingdan?id=' + id,
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }


    },
    application_return_list: function() {
        wx.showModal({
            title: '请前往电脑端进行操作',
            content: '网址为：http://www.wuhuaxingbang.com',
            success: function(res) {
                if (res.confirm) {

                } else if (res.cancel) {

                }
            }
        })

        // wx.navigateTo({
        //   url: '../wode/application_return_list/application_return_list',
        // })
    },


    // getUserInfo: function (e) {
    //   console.log(e)
    //   app.globalData.userInfo = e.detail.userInfo
    //   this.setData({
    //     userInfo: e.detail.userInfo,
    //     hasUserInfo: true
    //   })
    // }


    // 系统消息
    syssetMessage: function() {
        if (this.data.login == true) {
            wx.navigateTo({
                url: '../other/stylemessage/stylemessage',
            })
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    // 拼团
    team: function() {
        wx.navigateTo({
            url: '../collage/collage_home/collage_home',
        })
    }

});