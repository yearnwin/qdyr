// pages/sale/sale.js
var server = require('../../utils/server');
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sale_list:[],
    url: app.globalData.url,
    p:1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.loadSale();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.loadSale();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  loadSale: function () {
    var that = this;
    server.getJSON("/Activity/ajax_flash_sale", function (res) {
      var sale_list = res.data.result.flash_sale_goods;
      that.setData({
        sale_list:sale_list
      });
    });
  },
  showDetail: function (e) {
    var goodsId = e.currentTarget.dataset.goodsId;
    wx.navigateTo({
      url: "../goods/details/details?objectId=" + goodsId
    });
  },








   //上拉刷新
  onReachBottom: function () {
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    var p = that.data.p + 1;
    that.setData({
      p: p
    })
    setTimeout(() => {
      server.getJSON('/Activity/ajax_flash_sale/p/'+that.data.p,function(res){ 
        var len=res.data.result.flash_sale_goods.length;
        console.log(len);
        if(len>0){
          that.setData({
            sale_list:that.data.sale_list.concat(res.data.result.flash_sale_goods),
            // p:that.data.p+1
          });
        }
      })
    },3000)
  },


  // 下拉刷新
  onPullDownRefresh:function(){
    var that = this
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    that.setData({
      p:1
    })
    that.loadSale();
        //  server.getJSON('/Activity/ajax_flash_sale/p/'+this.data.p,function(res){ 
        //   var len=res.data.result.flash_sale_goods.length;
        //   console.log(len);
        //   if(len>0){
        //       that.setData({
        //         sale_list:res.data.result.flash_sale_goods,
        //         p:that.data.p+1
        //         });
        //   }
            
        // })

  }












})