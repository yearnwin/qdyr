var server = require('../../utils/server');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        files: [],
        describe: '',
        goods_id: '',
        item_id: '',
        action: '',
        goods_num: '',
        images: [],
        cus_wx: '',
        send_name: '',
        cus_phone:'',
        cus_note:'',
    },
    chooseImage: function (e) {
        var that = this;
        wx.chooseImage({
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片

                wx.uploadFile({
                    url: app.globalData.url + '/wxapi/Cart/test',
                    filePath: res.tempFilePaths[0],
                    name: 'content',
                    formData: { 'imgIndex': "user" },
                    success: function (res) {
                        var pic = JSON.parse(res.data).result;
                        // console.log(pic)
                        // console.log(res.tempFilePaths)
                        that.setData({
                            // images: that.data.images.concat(pic)
                            images: pic
                        });
                    }
                })
                that.setData({
                    // files: that.data.files.concat(res.tempFilePaths)
                    files: res.tempFilePaths
                });
            }
        })
    },
    previewImage: function (e) {
        wx.previewImage({
            current: e.currentTarget.id, // 当前显示图片的http链接
            urls: this.data.files // 需要预览的图片http链接列表
        })
    },
    // 微信
    wxDescribeInput: function (e) {
        console.log('微信：' + e.detail.value)
        this.setData({
            cus_wx: e.detail.value
        })
    },
    // 电话
    phoneDescribeInput: function (e) {
        console.log('电话：' + e.detail.value)
        this.setData({
            cus_phone: e.detail.value
        })
    },
    // 定制人姓名
    nameDescribeInput: function (e) {
        console.log('定制人姓名：' + e.detail.value)
        this.setData({
            send_name: e.detail.value
        })
    },
    // 备注
    remarkDescribeInput: function (e) {
        console.log('备注：' + e.detail.value)
        this.setData({
            cus_note: e.detail.value
        })
    },
    // 定制人寄语
    userDescribeInput: function (e) {
        console.log('描述：' + e.detail.value)
        this.setData({
            describe: e.detail.value
        })
    },
    formsubmit: function () {
        let custom_desc = this.data.describe;
        let custom_pic = this.data.images;
        console.log(custom_pic)
        let pic_length = this.data.files.length;
        let item_id = this.data.item_id;
        let goods_num = this.data.goods_num;
        let action = this.data.action;
        let goods_id = this.data.goods_id;
        let send_name = this.data.send_name;
        let cus_wx = this.data.cus_wx;
        let cus_phone = this.data.cus_phone;
        let cus_note = this.data.cus_note;
        console.log(custom_desc, custom_pic, item_id, goods_num, action, goods_id, cus_wx, send_name, cus_phone, cus_note)
        if (cus_wx == '') {
            wx.showToast({
                title: '输入微信！',
            })
            return;
        }
        if (cus_phone == '') {
            wx.showToast({
                title: '输入电话！',
            })
            return;
        }
        if (send_name == '' || send_name == 0) {
            wx.showToast({
                title: '输入定制人姓名！',
            })
            return;
        }
        // if (cus_note == '') {
        //     wx.showToast({
        //         title: '输入备注！',
        //     })
        //     return;
        // }
        if (custom_desc == '' || custom_desc == 0) {
            wx.showToast({
                title: '请输入寄语！',
            })
            return;
        }
        if (custom_pic.length == 0) {
            wx.showToast({
                title: '请上传图片！',
            })
            return;
        }
        wx.navigateTo({
            url: '../other/queren/queren?custom_desc=' + custom_desc + '&custom_pic=' + custom_pic + '&cus_wx=' + cus_wx + '&send_name=' + send_name + '&pic_length=' + pic_length + '&item_id=' + item_id + '&goods_num=' + goods_num + '&action=buy_now&goods_id=' + goods_id + '&cus_phone=' + cus_phone + '&cus_note=' + cus_note
        })
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var goods_id = options.goods_id;
        var item_id = options.item_id;
        var action = options.action;
        var goods_num = options.goods_num;
        console.log(goods_id, item_id, action, goods_num)
        this.setData({
            goods_id: goods_id,
            item_id: item_id,
            action: action,
            goods_num: goods_num,
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})