var server = require('../../../utils/server');
var app = getApp();
var WxParse = require('../../../wxParse/wxParse.js');


Page({
  data: {
    clock: '',
    head_pid:'',
    endtime:'',
    over_time:'',
    time_h:'00',
    time_m:'00',
    time_s:'00',
    shareimg:'',
    comderid:0,
    group_id:0,
    sharepath:'',
    objectId:'',
    head_pic:'',
    head_pics:'',
  },
  onLoad: function (options) {
    // var id = 1;
    // console.log(options)
    var wxtoken = wx.getStorageSync('wxtoken');
    var id = options.id;
    var objectId = options.objectId;
    this.setData({
      objectId: objectId,
    })
    var that = this;

     server.getJSON('/Order/pay_success/pay_id/' + id + '/wxtoken/' + wxtoken,function(res){
      if(res.data.status != -1){
      // console.log(res.data);

        var over_time=res.data.info.endtime;
        var comderid=res.data.info.comderid;
        var group_id=res.data.info.group_id;
        that.setData({
          id :id,
          user : res.data.user.user,
          head_pic :res.data.user.comder.head_pic,
          head_pics :res.data.user.user,
          nowsum:res.data.info.nowsum,
          shouldnum:res.data.info.shouldnum,
          num:res.data.info.shouldnum-res.data.info.nowsum,
          over_time:res.data.info.endtime,
          share :res.data.share,
          comderid:res.data.info.comderid,
          group_id:res.data.info.group_id,
        });
       that.flashTime(over_time);
      }
    });
     // that.goodsInfo();

  },

   flashTime: function (over_time) {
    var that = this;
    var over_time_nk = over_time;
    var totalSecond = over_time_nk - Date.parse(new Date()) / 1000;
    var interval = setInterval(function () {
      var second = totalSecond;

      var day = Math.floor(second / 3600 / 24);
      var dayStr = day.toString();
      if (dayStr.length == 1) dayStr = '0' + dayStr;

      var hr = Math.floor((second - day * 3600 * 24) / 3600);
      var hrStr = hr.toString();
      if (hrStr.length == 1) hrStr = '0' + hrStr;

      var min = Math.floor((second - day * 3600 * 24 - hr * 3600) / 60);
      var minStr = min.toString();
      if (minStr.length == 1) minStr = '0' + minStr;

      var sec = second - day * 3600 * 24 - hr * 3600 - min * 60;
      var secStr = sec.toString();
      if (secStr.length == 1) secStr = '0' + secStr;

      that.setData({
        time_h: hrStr,
        time_m: minStr,
        time_s: secStr,
        time :hrStr+minStr+secStr,
      });
      totalSecond--;
      if (totalSecond < 0) {
        clearInterval(interval);
        that.setData({
          time_h: '00',
          time_m: '00',
          time_s: '00',
          time : '0',
        });
      }

    }.bind(this), 1000);
  },
   onShow: function () {
    this.goodsInfo();
  },
  goodsInfo:function(){
    // id 是groupgoods里的id
    var that = this;
    var id = that.data.objectId;
    // console.log(that.data)
    // console.log(that.data.objectId)
     server.getJSON('/LoginApi/group_goods/id/' + id,function(res){
      // console.log(res.data);
      var list =res.data.list;
      var goods_content=res.data.list.goods_content;
      that.setData({
        list : res.data.list,
        goods_content : list.goods_content,
        goods_name : list.goods_name,
        img : list.img,
        shareimg : res.data.share.shareimg,
        sharepath : res.data.share.sharepath,
        team_price :list.team_price,
        shop_price :list.shop_price,
      });
        WxParse.wxParse('article', 'html', that.data.goods_content, that, 5);

    })

  },
  onShareAppMessage: function (ops) {
    console.log(this.data)
    var shareimg =this.data.shareimg;
    var sharepath = this.data.sharepath;
    var goods_name = this.data.goods_name;
     if (ops.from === 'button') {
      // 来自页面内转发按钮
      // console.log(ops.target)
    }
    return { 
      title: goods_name, 
      imageUrl:shareimg,


      // path:'/pages/collage/collage_detail/collage_detail?scene=' + 123 + '&first_leader =' + first_leader + '&group_id =' + group_id,
      path: sharepath,
      success: function (res) { 

      // 转发成功 
        console.log("转发成功:"); 
      }, 
      fail: function (res) { 
      // 转发失败 
      console.log("转发失败:"); 
    } 
  } 

  },


});