var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    amount: 0,
    order_sn: '',
    is_default: 0,
    payurl: '',
    id:0,
    objectId:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options)
    var order_sn = options.order_sn;
    var amount = options.amount;
    var payurl = options.payurl;
    var id = options.id;
    var user = options.user;
    var objectId = options.objectId;
    this.setData({
      order_sn: order_sn,
      amount: amount,
      payurl: payurl,
      id:id,
      user:user,
      objectId:objectId,
    });
    this.getUser();
  },

 
  
  // 会员信息
  getUser: function () {
    server.getJSON('/Cart/users/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      if (res.data.status == 1) {
        var company =res.data.user.company;
        var identity = res.data.user.identity;
        if (company == 1 && identity == 1) {
          this.setData({
            is_default: 1
          })
        }
      }
    });
  },
  // 微信支付
  wxPay: function () {
    wx.request({
      url: app.globalData.url + '/wxapi/Order/getPrePayIds',
      data: {
        wxtoken: wx.getStorageSync('wxtoken'),
        id: this.data.id,
        order_id: this.data.order_sn,
        appid :app.globalData.appid,
        openid:app.globalData.openid,
      },
      method: 'POST',
      success: function (res) {
        // console.log(res);
        if(res.data.status != -1){
           wx.requestPayment({
          'timeStamp': res.data.timeStamp,
          'nonceStr': res.data.nonceStr,
          'package': res.data.package,
          'signType': res.data.signType,
          'paySign': res.data.paySign,
          'success': function (res) {
            this.paySuccess();
          },
          'fail': function (res) {
              wx.showToast({ title: '支付失败', icon: 'success', duration: 2000 })
            }
          })  
        }else{
          wx.showToast({
            title:res.data.msg,
            icon:'none',
          })
          wx.navigateTo({
            url:'../../wode/choice/choice'
          })
        }
       
      }
    })
  },
  // wxPay:function(){
  //   var id = this.data.id;
  //   var objectId = this.data.objectId;
  //   wx.navigateTo({
  //     url:'../collage_success/collage_success?id=' + id +'&objectId=' +objectId,
  //   })
  // },
  
  // 支付成功后返回
  paySuccess: function () {
    wx.showModal({
      title: '提示',
      content: '支付成功',
      cancelText: '返回首页',
      confirmText: '订单详情',
      cancelColor: '#000000',
      confirmColor: '#3cc51f',
      success: function (res) {
        // console.log(res)
        if (res.confirm) {
          wx.navigateTo({
            url: '../collage_success/collage_success?id='+this.data.id,
          })
        } else if (res.cancel) {
          wx.switchTab({
            url: '../collage_home/collage_home',
          })
        }
      }
    })
  },
})