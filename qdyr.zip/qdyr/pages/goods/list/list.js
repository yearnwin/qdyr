var server = require('../../../utils/server');
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageurl1: "../../../image/sort-tip_03.png",
    daindex1: 0,
    imageurl2: "../../../image/sort-tip_03.png",
    daindex2: 0,
    goods_list: '',
    url: app.globalData.url,

    p: 1,
    id: 0,
    sort: '',//价格
    sort_asc: '',//销量
    sel: '',
    q: '',//关键字
   
  
  },
  // 销量
  choosesort1: function(e) {
    var that = this
    if (that.data.daindex1 == 0) {
      that.setData({
        imageurl1: "../../../image/sort-tip_03.png",
        daindex1: 1,
        sort_asc: 'desc',
        sort: 'sales_sum',
        p: 1
      })
      // console.log(that.data.id);

      // if (that.data.id == '') {

      //   console.log('搜索销量');
      //   server.getJSON('/Goods/search/sort/sales_sum/sort_asc/desc/', function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });

      // } else {
      //   console.log('销量高---------------------------低');
      //   server.getJSON('/Goods/goods_list/sort/sales_sum/sort_asc/desc/id/' + that.data.id, function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });

      // }


    } else {
      // console.log(that.data.id);

      this.setData({
        imageurl1: "../../../image/sort-tip_05.png",
        daindex1: 0,
        sort_asc: 'asc',
        sort: 'sales_sum',
        p: 1
      })
      // if (that.data.id == '') {
      //   console.log('搜索销量');
      //   server.getJSON('/Goods/search/sort/sales_sum/sort_asc/asc/', function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });
      // } else {
      //   console.log('销量低---------------------------高');

      //   server.getJSON('/Goods/goods_list/sort/sales_sum/sort_asc/asc/id/' + that.data.id, function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });
      // }

    }
    this.loadGoodsList();
  },


  //价格
  choosesort2: function(e) {
    var that = this
    if (that.data.daindex2 == 0) {
      that.setData({
        imageurl2: "../../../image/sort-tip_03.png",
        daindex2: 1,
        sort: 'shop_price',
        sort_asc: 'desc',
        p: 1
      })

      // if (that.data.id == '') {
      //   console.log('搜索价格');
      //   console.log(that.data.id);
      //   server.getJSON('/Goods/search/sort/shop_price/sort_asc/desc/', function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });
      // } else {
      //   console.log('价格高---------------------------------------->低');
      //   console.log(that.data.id);
      //   server.getJSON('/Goods/goods_list/sort/shop_price/sort_asc/desc/id/' + that.data.id, function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });
      // }

    } else {
      // console.log(that.data.id);

      that.setData({
        imageurl2: "../../../image/sort-tip_05.png",
        daindex2: 0,
        sort: 'shop_price',
        sort_asc: 'asc',
        p:1
      })
      // if (that.data.id == '') {
      //   console.log('搜索价额');
      //   server.getJSON('/Goods/search/sort/shop_price/sort_asc/asc/', function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });
      // } else {
      //   console.log('低--------------------------------->高');

      //   server.getJSON('/Goods/goods_list/sort/shop_price/sort_asc/asc/id/' + that.data.id, function(res) {
      //     console.log(res);
      //     that.setData({
      //       goods_list: res.data.result.list
      //     })
      //   });

      // }
    }
    that.loadGoodsList();
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    if (options.objectId){
      that.setData({
        id: options.objectId,
      })
    }
    if (options.q) {
      that.setData({
        q: options.q
      })
    }
    // var cateId = options.objectId;
    // var q = options.q;
    // that.setData({
    //   id: options.objectId,
    //   q: q
    // })
    that.loadGoodsList();
    // if (options.q) {

    //   server.getJSON('/Goods/search/q/' + options.q + '/unionid/' + app.globalData.unionId, function(res) {

    //     if (res.data.list == '') {
    //       wx.showToast({
    //         title: '找不到',
    //       })

    //     } else {
    //       that.setData({
    //         goods_list: res.data.list
    //       })
    //     }

    //   })
    // } else {
    //   this.loadGoodsList(cateId);
    // }

  },
  //综合
    colligate:function(e){
      //     console.log(e);
      // var id=e.target.dataset.id;
      //       console.log(id);
      // this.loadGoodsList(id);
      this.setData({
        imageurl1: "../../../image/sort-tip_03.png",
        daindex1: 0,
        imageurl2: "../../../image/sort-tip_03.png",
        daindex2: 0,
        p: 1,
        sort: '',//价格
        sort_asc: '',//销量
      })
      this.loadGoodsList();
    },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  showDetail: function(e) {
    var goodsId = e.currentTarget.dataset.goodsId;
    wx.navigateTo({
      url: "../details/details?objectId=" + goodsId
    });
  },

  //商品列表
  loadGoodsList: function(cateId, str) {
    var that = this
    // var unionId = app.globalData.unionid;
    var cateId = that.data.id;
    var sort = that.data.sort;
    var sort_asc = that.data.sort_asc;
    var q = that.data.q;
    var sel = that.data.sel;
    var page = that.data.p;

    var urlCode = '';
    if (cateId != 0) {
      urlCode = 'goods_list';
    } else if (q != '') {
      urlCode = 'search';
    }

    // server.getJSON('/Goods/' + urlCode + '/id/' + cateId + '/sort/' + sort + '/sort_asc/' + sort_asc + '/q/' + q + '/p/' + page, function (res) {
    //   var goods_list = res.data.result.list;

    //   that.setData({
    //     goods_list: goods_list
    //   });
    // });

    wx.request({
      url: app.globalData.url + '/wxapi/Goods/' + urlCode,
      data: {
        wxtoken: wx.getStorageSync('wxtoken'),
        p: page,
        id: cateId,
        sort: sort,
        sort_asc: sort_asc,
        sel: sel,
        q: q
      },
      method: 'POST',
      success: function (res) {
        if (res.data.result.list != '') {
          var goods_list = res.data.result.list;
          that.setData({
            goods_list: goods_list
          });
        }
      }
    })
    // server.getJSON('/Goods/goods_list/id/' + cateId, function(res) {
    //   var goods_list = res.data.result.list;

    //   that.setData({
    //     goods_list: goods_list
    //   });
    // });

  },


  //系统消息
  sys: function() {
    wx.navigateTo({
      url: '../sys/sys',
    })
  },

  //上拉刷新
  onReachBottom: function () {
   var that = this   
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    wx.showToast({
      title: '加载中...',
      icon: 'loading'
    })
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);       
        //  server.getJSON('/Goods/goods_list/id/'+this.data.id+'/p/'+this.data.p,function(res){ 
        //   var len=res.data.result.list.length;
        //   console.log(len);
        //   if(len>0){
        //     that.setData({
        //       goods_list: that.data.goods_list.concat(res.data.result.list),
        //       p: that.data.p + 1
        //     });
        //   }         
        // })
    var p = that.data.p + 1;
    that.setData({
      p: p
    })
    var cateId = that.data.id;
    var sort = that.data.sort;
    var sort_asc = that.data.sort_asc;
    var q = that.data.q;
    var sel = that.data.sel;
    var page = that.data.p;

    var urlCode = '';
    if (cateId != 0) {
      urlCode = 'goods_list';
    } else if (q != '') {
      urlCode = 'search';
    }
    wx.request({
      url: app.globalData.url + '/wxapi/Goods/' + urlCode,
      data: {
        wxtoken: wx.getStorageSync('wxtoken'),
        p: page,
        id: cateId,
        sort: sort,
        sort_asc: sort_asc,
        sel: sel,
        q: q
      },
      method: 'POST',
      success: function (res) {
        if (res.data.result.list != '') {
          var goods_list = res.data.result.list;
          that.setData({
            goods_list: that.data.goods_list.concat(goods_list)
          });
        }
      }
    })
  },
  // 下拉刷新
  onPullDownRefresh:function(){
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载
    this.setData({
      p: 1
    })
    this.loadGoodsList();
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  }
})