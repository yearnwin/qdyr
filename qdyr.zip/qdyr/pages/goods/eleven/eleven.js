var server = require('../../../utils/server');
var WxParse = require('../../../wxParse/wxParse.js');
var app = getApp();
Page({
  data: {
    goods_list: {},
    picture: '',
    url: app.globalData.url,
    imgUrls: [

      {



        url: 'http://img3.imgtn.bdimg.com/it/u=2200166214,500725521&fm=26&gp=0.jpg'

      }, {



        url: 'http://img3.imgtn.bdimg.com/it/u=2200166214,500725521&fm=26&gp=0.jpg'

      }, {



        url: 'http://img3.imgtn.bdimg.com/it/u=2200166214,500725521&fm=26&gp=0.jpg'

      }, {



        url: 'http://img3.imgtn.bdimg.com/it/u=2200166214,500725521&fm=26&gp=0.jpg'

      }

    ],

    indicatorDots: true,  //小点

    autoplay: true,  //是否自动轮播

    interval: 3000,  //间隔时间

    duration: 300,  //滑动时间
    p: 1,
    yy: 0

  },


  onLoad: function (options) {

      this.yy();
   
  },

  //雙十一
  yy: function () {
    var that = this

    server.getJSON('/index/yy', function (res) {
      console.log(res);
      console.log(res.data.result);
      var goods_list = res.data.result[0].goods;
      var picture = res.data.result[0].ad_code;
      console.log(goods_list);
      console.log('godssss------------------');
      console.log(picture);
      that.setData({
        goods_list: goods_list,
        picture: picture,
      });

    });

  },


  // 商品
  getGoods: function () {
    var that = this
    server.getJSON('/Goods/com_mall/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      var goods_list = res.data.result.goods;
      var picture = res.data.result.banner;
      console.log('-------------------------goods----------------');
      console.log(goods_list);
      console.log('pic--------------------------');
      console.log(picture);
      that.setData({
        goods_list: goods_list,
        picture: picture,
      });
    });
  },
  //商品详情
  showDetail: function (e) {
    var goodsId = e.currentTarget.dataset.goodsId;
    wx.navigateTo({
      url: "../details/details?objectId=" + goodsId
    });
  },

  advUrl: function (event) {
    var jump_type = event.currentTarget.dataset.jumpType;
    var jump_url = event.currentTarget.dataset.jumpUrl;

    if (jump_type == 0) {
      wx.navigateTo({
        url: "../ceshi/ceshi?objectId=" + jump_url,
      });
    } else if (jump_type == 1) {
      wx.navigateTo({
        url: "../details/details?objectId=" + jump_url,
      });
    } else if (jump_type == 2) {
      wx.navigateTo({
        url: "../list/list?objectId=" + jump_url,
      });
    } else {
      url: "../activity_goodspages/goods/mall/mall?objectId=" + jump_url
    }
  },

  onShareAppMessage: function () {
    return {
      title: '物华兴邦',
      desc: '物华兴邦',
      path: '/pages/index/index'
    }
  },

  //  //上拉刷新
  //  onReachBottom: function () {
  //    var that = this
  //         wx.showNavigationBarLoading() //在标题栏中显示加载  
  //         //模拟加载
  //         setTimeout(function()
  //         {
  //           wx.hideNavigationBarLoading() //完成停止加载
  //           wx.stopPullDownRefresh() //停止下拉刷新
  //         },1000);

  //          server.getJSON('/Goods/com_mall/p/'+this.data.p,function(res){ 
  //           var len=res.data.result.goods.length;
  //           console.log(len);
  //           console.log(res);

  //           if(len>0){
  //               that.setData({
  //                 goods_list:res.data.result.goods,
  //                 p:that.data.p+1
  //                 });
  //           }

  //         })
  //   },

  // 下拉刷新
  onPullDownRefresh: function () {
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function () {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1000);
    that.getGoods();
    //  server.getJSON('/Goods/com_mall/p/'+this.data.p,function(res){ 
    //   var len=res.data.result.goods.length;
    //   console.log(len);
    //   console.log(res);

    //   if(len>0){
    //       that.setData({
    //         goods_list:res.data.result.goods,
    //         p:that.data.p+1
    //         });
    //   }

    // })

  }
});