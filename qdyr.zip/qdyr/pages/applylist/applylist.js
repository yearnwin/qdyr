// pages/applylist/applylist.js
var server = require('../../utils/server');
var app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        agency_status: '',
        manager_status: '',
        login: false,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let login=wx.getStorageSync('login')
        this.setData({
            login,
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        this.applyjd();
        let login = wx.getStorageSync('login')
        let is_county = wx.getStorageSync('is_county')
        let is_managers = wx.getStorageSync('is_managers')
        this.setData({
            login,
            is_county,
            is_managers,
        })
    },
    applyjd: function() {
        let that = this;
        wx.request({
            url: app.globalData.url + '/wxapi/user/agency',
            data: {
                // username: username,
                // idnumber: idnumber,
                // county: county,
                wxtoken: wx.getStorageSync('wxtoken')
            },
            method: 'POST',
            dataType: 'json',
            success(res) {
                console.log(res.data.status)
                if (res.data.status == 2) {
                    that.setData({
                        agency_status: res.data.status
                    })
                }
            }
        })
        wx.request({
            url: app.globalData.url + '/wxapi/user/managers',
            data: {
                // username: username,
                // idnumber: idnumber,
                // county: county,
                wxtoken: wx.getStorageSync('wxtoken')
            },
            method: 'POST',
            dataType: 'json',
            success(res) {
                console.log(res.data.status)
                if (res.data.status == 2) {
                    that.setData({
                        manager_status: res.data.status
                    })
                }
            }
        })
    },
    applyagency: function() {
        let that = this;
        if (that.data.login) {
            if (that.data.manager_status == 2) {
                wx.showToast({
                    title: '审核中',
                    duration: 2000
                })
            } else {
                wx.navigateTo({
                    url: '../wode/agency/agency',
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    applymanager: function () {
        let that = this;
        if (that.data.login) {
            if (that.data.manager_status == 2) {
                wx.showToast({
                    title: '审核中',
                    duration: 2000
                })
            } else {
                wx.navigateTo({
                    url: '../wode/manager/manager',
                })
            }
        } else {
            wx.navigateTo({
                url: '../wode/choice/choice',
            })
        }
    },
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})