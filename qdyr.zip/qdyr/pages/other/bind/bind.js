var server = require('../../../utils/server');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    mobile: '',
    code: '',
    title: '获取验证码',
    token: '',
    id: 0,
    unique_id: 'dsfuhbsdhfgjosdjfgklsnfgnsdk',
      region: ['请选择'],
  },
    // 地址
    bindRegionChange(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
            region: e.detail.value
        })
    },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var id = options.id;
    this.setData({
      id: id
    })
    // this.userInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */

  // //下拉刷新
  // onPullDownRefresh: function () {
  //   wx.showNavigationBarLoading() //在标题栏中显示加载  
  //   //模拟加载
  //   setTimeout(function () {
  //     wx.hideNavigationBarLoading() //完成停止加载
  //     wx.stopPullDownRefresh() //停止下拉刷新
  //   }, 1000);
  // },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // userInfo: function () {
  //   var that = this;
  //   server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
  //     var info = res.data.result.info;
  //     that.setData({
  //       token: info.token
  //     });
  //     // console.log(info)
  //   });
  // },
  // 手机号
  getPhone: function (e) {
    // console.log(e.detail.value);
    this.setData({
      mobile: e.detail.value,
    })
  },
  // 获取验证码
  getCode: function () {
    var that = this;
    var mobile = this.data.mobile;
      var region = this.data.region;
    if (mobile == '') {
      wx.showToast({
        title: '请输入手机号！',
      })
    }else if (region == '请选择') {
          wx.showToast({
              title: '请选择地址',
              icon: 'none',
          });
      } else {
      wx.request({
        url: app.globalData.url + '/wxapi/LoginApi/issetMobile',
        data: {
          mobile: mobile,
          region: region
        },
        method: 'POST',
        success(res) {
          if (res.data.status == 1) {
            
            wx.request({
              url: app.globalData.url + '/home/Api/send_validate_code/t/' + Math.random(),
              data: {
                unique_id: that.data.unique_id,
                type: 'mobile',
                send: mobile,
                scene: 6
              },
              method: 'POST',
              success(res) {
                if (res.data.status == 1) {
                  wx.showToast({
                    title: res.data.msg,
                  })
                  that.countDown();
                } else {
                  wx.showToast({
                    title: res.data.msg,
                  })
                }
              }
            })
          } else {
            wx.showToast({
              title: res.data.msg,
            })
          }
        }
      })
    }
  },
  // 倒计时
  countDown: function () {
    var that = this;
    var totalSecond = 120;
    var interval = setInterval(function () {
      var second = totalSecond;
      that.setData({
        title: second + '秒后再获取',
      });
      totalSecond--;
      if (totalSecond < 0) {
        clearInterval(interval);
        that.setData({
          title: '获取验证码',
        });
      }

    }.bind(this), 1000);
  },
  // 提交
  formSubmit: function (e) {
    // console.log('form发生了submit事件，携带数据为：', e.detail.value.phone)
    var that = this;
    var mobile = e.detail.value.phone;
    var code = e.detail.value.mobile_code;
    var region = that.data.region;
    if (mobile == '') {
      wx.showToast({
        title: '请输入手机号！',
      })
    } else if (code == '') {
      wx.showToast({
        title: '请输入验证码！',
      })
    } else {
      server.getJSON('/LoginApi/bind_mobile/unique/' + that.data.unique_id + '/mobile/' + mobile + '/region/' + region + '/code/' + code + '/id/' + that.data.id + '/first_leader/' + wx.getStorageSync('app_send_user_id'), function (res) {
        if (res.data.status == 1) {
          wx.setStorageSync('wxtoken', res.data.wxtoken);//緩存--wxtoken
          wx.navigateBack({
            delta: 2
          })    
        } else {
          wx.showToast({
            title: res.data.msg,
          })
        }
      });
    }
  },

})