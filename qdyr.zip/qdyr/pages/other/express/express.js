// pages/other/express/express.js
var server = require('../../../utils/server');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address:'',
    order_sn:'',
    time:0,
    code:'',
    no:'',
    status:'',
    nu:'',
    com:'',
    postname:'',


    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('soptions');
    console.log(options);

    var id=options.id
    this.express(id);
     
  },
  //物流
  express:function(id){
    var that= this
    console.log('kahdkjfhakshd');
   
    server.getJSON('/order/express_new/rec_id/' + id + '/wxtoken/' + wx.getStorageSync('wxtoken'),function(res){
      console.log(code);
        that.setData({
          postname: res.data.delivery.shipping_name,
           code : res.data.delivery.shipping_code,
           no : res.data.delivery.invoice_no,
          order_sn: res.data.delivery.order_sn,
          time: res.data.delivery.add_time,
          
        })


     var code = that.data.code;
      var no=that.data.no;
      var order_sn=that.data.order_sn
      server.getJSON('/api/queryexpress/wxtoken/' + wx.getStorageSync('wxtoken') + '/order_sn/' + order_sn + '/shipping_code/' + code +'/invoice_no/'+no, function (ress) {
          console.log(res);
          that.setData({
            status:ress.data.data,
            nu:ress.data.nu,
            com:ress.data.com
          })
        if(ress=='')
          {
          server.getJSON('/api/queryExpress/wxtoken/' + wx.getStorageSync('wxtoken') + '/order_sn/' + order_sn + '/shipping_code/' + code + '/invoice_no/' + no+'/order_sn/'+order_sn,function(resss){
                console.log('ssss');
                console.log(resss);
            })

          }


      })




      })

      



  
  },
 



  //时间戳转换成日期



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  
//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },


  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})