var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置
var server = require('../../../utils/server');
var app = getApp();
Page({
  data: {
    details_list: [],
    count: '0.00'
  },
  onLoad: function (options) {
    this.getList();
  },
  getList: function () {
    var that = this;
    server.getJSON('/User/withdrawals_list/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      if (res.data.status == 1) {
        var details_list = res.data.list;
        var count = res.data.count;
        that.setData({
          details_list: details_list,
          count: count
        })
      }else{
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },
  
//下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
  },


  
});