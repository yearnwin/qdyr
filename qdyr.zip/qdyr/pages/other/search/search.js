var server = require('../../../utils/server');
var app = getApp();
Page({
  data: {
    // 搜索框状态
    inputShowed: false,
    // 搜索框值
    inputVal: "",
    //搜索渲染推荐数据
    searchRecord: [],
    search_hot: '',
    list: ''
  },

  // 显示搜索框
  showInput: function() {
    this.setData({
      inputShowed: true
    });
  },

  openHistorySearch: function() {
    this.setData({
      searchRecord: wx.getStorageSync('searchRecord') || [], //若无储存则为空
    })
  },

  onLoad: function(options) {
    var that = this
    server.getJSON('/MobileBase/public_assign', function(res) {
      that.setData({
        search_hot: res.data.result.hot_keywords
      });
    });
  },

  onShow: function () {
    this.openHistorySearch()
  },
   

  //搜索
  search: function(e) {
    // console.log(e)
    var that = this
    var inputVal = e.detail.value.goods_name;
    var searchRecord = that.data.searchRecord;
    if (inputVal == '') {
      //输入为空时的处理
      wx.showToast({
        title: '请输入搜索内容',
        icon:'none',
      })
    } else {
      //将搜索值放入历史记录中,只能放前五条
      var resid = -1
      if (searchRecord.length > 0){
        for (var i = 0; i < searchRecord.length; i++) {
          if (that.data.inputVal == wx.getStorageSync('searchRecord')[i].value){
            resid = i
          }
        }
      }
      if (resid != -1){
        // arr.splice(arrnum, 1)
        // arr.unshift(that.data.inputVal);
      }else{
        if (searchRecord.length < 5) {
          // 判断值是否存在
          searchRecord.unshift({
            value: inputVal,
            // id: searchRecord.length
          })
        } else {
          searchRecord.pop() //删掉旧的时间最早的第一条
          searchRecord.unshift({
            value: inputVal,
            // id: searchRecord.length
          })
        }
        //将历史记录数组整体储存到缓存中
        wx.setStorageSync('searchRecord', searchRecord)
      }
    
      wx.navigateTo({
        url: '../../goods/list/list?q=' + inputVal,
      })
      
    }
  },

  history: function(e) {
    var inputVal = e.currentTarget.dataset.name;
    wx.navigateTo({
      url: '../../goods/list/list?q=' + inputVal,
    })
  },

  // 隐藏搜索框样式
  hideInput: function() {
    this.setData({
      inputVal: "",
      inputShowed: false
    });
  },
  // 清除搜索框值
  clearInput: function() {
    this.setData({
      inputVal: ""
    });
  },


  // 获取搜索框值
  inputTyping: function(e) {
    var that = this
    that.setData({
      inputVal: e.detail.value
    });
  },


  // 获取选中推荐列表中的值
  btn_name: function(res) {
    console.log(res.currentTarget.dataset.index);
    console.log(res);
    var id = res.target.dataset.id;
    console.log(id);

    wx.navigateTo({
      url: "../../goods/list/list?objectId=" + res.target.dataset.id,
    })
  },

  //删除历史记录
  historyDelFn: function() {
    wx.clearStorageSync('searhRecord')
    this.setData({
      searchRecord: []
    })
  },

});