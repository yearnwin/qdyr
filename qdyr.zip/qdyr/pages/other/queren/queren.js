var server = require('../../../utils/server');
var app = getApp();
Page({
    /**
     * 页面的初始数据
     */
    data: {
        shows: false,
        checked: 0,

        action: '',
        address: '',
        goods_list: [],
        coupon_list: [],
        url: app.globalData.url,
        user: '',
        total_fee: 0,
        coupon_id: '',
        user_money: 0,
        can_use_money: 0,
        address_id: '',
        userCouponNum: 0,
        auth_code: 'TPSHOP',
        invoice_title: '个人',
        radio_title: '个人',
        radio_cont: '不开发票',
        pay_points: '',
        couponCode: '',
        payPwd: '',
        user_note: '',
        goods_id: '',
        item_id: '',
        action: '',
        goods_num: '',
        files: [],
        describe: '',
        level:'',
        send_name: '',
        cus_wx:'',
        cus_phone:'',
        cus_note:'',

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        var goods_id = options.goods_id;
        var item_id = options.item_id;
        var action = options.action;
        var goods_num = options.goods_num;
        let custom_desc = options.custom_desc;
        let custom_pic = options.custom_pic;
        let pic_length = options.pic_length;
        let send_name = options.send_name;
        let cus_wx = options.cus_wx;
        let cus_phone = options.cus_phone;
        let cus_note = options.cus_note;
        console.log(goods_id, item_id, action, goods_num, custom_desc, custom_pic, send_name, cus_wx)
        if (custom_desc != undefined && custom_pic != undefined && pic_length != undefined){
            this.setData({
                goods_id: goods_id,
                item_id: item_id,
                action: action,
                goods_num: goods_num,
                files: custom_pic,
                describe: custom_desc,
                pic_length: pic_length,
                send_name: send_name,
                cus_wx: cus_wx,
                cus_phone: cus_phone,
                cus_note: cus_note,
            })
        }else{
            this.setData({
                goods_id: goods_id,
                item_id: item_id,
                action: action,
                goods_num: goods_num,
                files: 0,
                describe: 0,
                send_name: 0,
                cus_wx: 0,
                cus_note: 0,
                cus_phone:0,
            })
        }
        
        // var address = options.address;
        // var address_id = options.address_id;
        // if (address_id > 0) {
        //   this.setData({
        //     address_id: address_id
        //   })
        // }
        // if (address != '') {
        //   this.setData({
        //     address: address
        //   })
        // }
        this.getCart();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
        let level = wx.getStorageSync('level')
        console.log(level)
        this.setData({
            level
        })
        this.getCart();
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */

    //下拉刷新
    onPullDownRefresh: function() {
        wx.showNavigationBarLoading() //在标题栏中显示加载  
        //模拟加载
        setTimeout(function() {
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
        }, 1000);
    },



    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    },
    addList: function() {
        let goods_id = this.data.goods_id;
        let item_id = this.data.item_id;
        let action = this.data.action;
        let goods_num = this.data.goods_num;
        let custom_pic = this.data.files;
        let custom_desc = this.data.describe;
        let send_name = this.data.send_name;
        let cus_wx = this.data.cus_wx;
        let pic_length = this.data.pic_length;
        let cus_phone = this.data.cus_phone;
        let cus_note = this.data.cus_note;
        console.log('给地址页面发送参数：' + goods_id + ':' + item_id + ':' + action + ':' + goods_num + ':' + custom_pic + ':' + custom_desc)
        wx.navigateTo({
            url: '../../wode/address_manage/address_manage?goType=1&goods_id=' + goods_id + '&item_id=' + item_id + '&action=' + action + '&goods_num=' + goods_num + '&custom_pic=' + custom_pic + '&custom_desc=' + custom_desc + '&cus_wx=' + cus_wx + '&send_name=' + send_name + '&pic_length=' + pic_length + '&cus_phone=' + cus_phone + '&cus_note=' + cus_note
        })
    },
    // 打开-关闭-优惠券
    switch1Change: function(e) {
        var that = this;
        var shows = e.detail.value
        that.setData({
            shows: shows
        });
        if (shows == false) {
            that.setData({
                coupon_id: '',
            });
        }
        that.orderPrice();
    },
    // 使用优惠券
    useCoupon: function(e) {
        var that = this;
        var couponId = e.currentTarget.dataset.couponId;
        that.setData({
            coupon_id: couponId,
            total_fee: 0,
        });
        that.orderPrice();
    },
    // 奖励金
    bindCheckbox: function(e) {
        var that = this;
        var checked = e.currentTarget.dataset.index;
        var canUse = e.currentTarget.dataset.canUse;
        that.setData({
            total_fee: 0,
            checked: checked,
            user_money: canUse
        })
        that.orderPrice();
    },
    // 初始数据
    getCart: function() {
        var that = this;
        server.getJSON('/Cart/cart2/wxtoken/' + wx.getStorageSync('wxtoken') + '/action/' + that.data.action + '/goods_id/' + that.data.goods_id + '/goods_num/' + that.data.goods_num + '/item_id/' + that.data.item_id, function(res) {
            console.log(res)
            if (res.data.status == 1) {
                var goods_list = res.data.result.cartList;
                var coupon_list = res.data.result.userCartCouponList;
                var user = res.data.result.user;
                var couponNum = res.data.result.userCouponNum;
                that.setData({
                    goods_list: goods_list,
                    coupon_list: coupon_list,
                    user: user,
                    can_use_money: user.user_money,
                    userCouponNum: couponNum.usable_num
                });
                if (res.data.result.address) {
                    var address = res.data.result.address;
                    console.log(address)
                    that.setData({
                        address: address,
                        address_id: address.address_id,
                    })
                }
                that.orderPrice();
            } else {
                wx.showToast({
                    title: '抱歉没有商品',
                })
            }
        });
    },
    // 计算价格
    orderPrice: function() {
        // console.log(this.data);
        var that = this;
        wx.request({
            url: app.globalData.url + '/wxapi/Cart/cart3',
            data: {
                wxtoken: wx.getStorageSync('wxtoken'),
                coupon_id: that.data.coupon_id,
                act: 'order_price',
                user_money: that.data.user_money,
                goods_id: that.data.goods_id,
                goods_num: that.data.goods_num,
                item_id: that.data.item_id,
                action: that.data.action
            },
            method: 'POST',
            success(res) {
              console.log(res.data);
                if (res.data.status == 1) {
                    that.setData({
                        total_fee: res.data.result.order_amount
                    })
                } else {
                    wx.showToast({
                        title: res.data.msg
                    })
                }
            }
        })
    },
    // 立即购买
    buyNows: function() {
        var that = this;
        var address_id = that.data.address_id;
        if (address_id == '') {
            wx.showToast({
                title: '请设置收货地址',
            })
        } else {
            wx.request({
                url: app.globalData.url + '/wxapi/Cart/cart3',
                data: {
                    wxtoken: wx.getStorageSync('wxtoken'),
                    coupon_id: that.data.coupon_id,
                    act: 'submit_order',
                    user_money: that.data.user_money,
                    address_id: address_id,
                    goods_id: that.data.goods_id,
                    goods_num: that.data.goods_num,
                    item_id: that.data.item_id,
                    action: that.data.action,
                    custom_pic: that.data.files,
                    custom_desc: that.data.describe,
                    cus_wx: that.data.cus_wx,
                    send_name: that.data.send_name,
                    cus_phone: that.data.cus_phone,
                    cus_note: that.data.cus_note
                },
                method: 'POST',
                success(res) {
                    console.log(res);
                    if (res.data.status == 1) {
                        if (res.data.amount == 0) {
                            wx.navigateTo({
                                url: '../../wode/orderdetails/orderdetails?order_id=' + res.data.id,
                            })
                        } else {
                            wx.navigateTo({
                                url: '../../other/pay/pay?order_id=' + res.data.id + '&amount=' + res.data.amount + '&payurl=1' + '&custom_pic=' + res.data.custom_pic + '&custom_desc=' + res.data.custom_desc + '&cus_wx=' + res.data.cus_wx + '&send_name=' + res.data.send_name + '&cus_phone=' + that.data.cus_phone + '&cus_note=' + that.data.cus_note,
                            })
                        }
                    } else {
                        wx.showToast({
                            title: res.data.msg
                        })
                    }
                }
            });
        }
    }
});