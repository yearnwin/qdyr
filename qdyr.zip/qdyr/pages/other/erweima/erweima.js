// pages/other/erweima/erweima.js
var app = getApp();
var server = require('../../../utils/server');

Page({

  /**
   * 页面的初始数据
   */
  data: {
      
      // imgUrl:'',
      // message:'',
      user_id:0,
      nickname:'',
      identity:0,
    wxtoken:  wx.getStorageSync('wxtoken')

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      var that=this;
    server.getJSON('/User/userinfo/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
        // console.log(res.data.result.info);
        if (res.data.status == 1) {
          var user_id = res.data.result.info.user_id;
          // console.log(user_id)
          var nickname = res.data.result.info.nickname;
          var identity = res.data.result.info.identity;
          that.setData({
            user_id:user_id,
            nickname:nickname,
            identity:identity,
            wxtoken: wx.getStorageSync('wxtoken')
          })
        } else if (res.data.status == -1) {
          wx.navigateTo({
            url: '../../wode/choice/choice',
          })
        }
      });
    // wx.getSetting({
    //   success: function (res) {
    //     // console.log(res)
    //     if (res.authSetting['scope.userInfo']) {
    //       that.setData({
    //         sqhide: 'sqhidec'
    //       });
    //       wx.getUserInfo({
    //         success: ({ userInfo }) => {
    //           // console.log(userInfo)
    //           that.setData({
    //             userInfo: userInfo
    //           });
    //           app.globalData.userInfo.nickName = userInfo.nickName;
    //           app.globalData.userInfo.avatarUrl = userInfo.avatarUrl;
    //           app.globalData.userInfo.user_id = userInfo.user_id;
    //           app.globalData.userInfo.identity = userInfo.identity;
    //         }
    //       })
    //       // console.log(app.globalData)

    //     } else {
    //       wx.showModal({
    //         title: '确认授权',
    //         content: '尚未进行授权，请去授权跳转到授权页面点击微信登录',
    //         confirmText: "去授权",
    //         cancelText: "取消",
    //         success: function (res) {
    //           // console.log(res);
    //           if (res.confirm) {
    //             wx.navigateTo({
    //               url: '../../wode/choice/choice',
    //             })
    //           } else {

    //           }
    //         }
    //       });
    //     }
    //   }
    // })   
      
  },
  onShow: function(options){
    // // console.log(options)
    // var that = this;
    // // 调用小程序 API，得到用户信息
    // wx.getUserInfo({
    //   success: ({ userInfo }) => {
    //     that.setData({
    //       userInfo: userInfo
    //     });
    //   }
    // });
     
  },

  /**
   * 用户点击右上角分享
   */
    onShareAppMessage: function () {
 
      var user_id= this.data.user_id;
      var nickname =this.data.nickname;
      var identity =this.data.identity;
      var scene = 1;

    return {
      title: '亿人定制',
      desc: '亿人定制',
      path: '/pages/index/index?user_id=' + user_id + '&nickname=' + nickname + '&identity=' + identity + '&scene=' + scene
    }
  },
})