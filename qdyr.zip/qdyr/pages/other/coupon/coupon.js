var server = require('../../../utils/server');
var app = getApp();
Page({
  data: {
    coupon_list: {},
    current: 0,
    tabStates: [true, false, false],
    tabClasss: ["text-select", "text-normal", "text-normal"],
    galleryHeight: getApp().screenWidth,
    tab: 0,
    p: 1
  },

  onLoad: function (options) {
    this.getCoupon();
  },
  tabClick: function (e) {
    var index = e.currentTarget.dataset.index;
    var classs = ["text-normal", "text-normal", "text-normal"];
    classs[index] = "text-select";
    this.setData({ tabClasss: classs, tab: index });
    this.getCoupon();
  },
  getCoupon: function () {
    var that = this
    var tab = that.data.tab;
    server.getJSON('/User/coupon/type/' + tab + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      if (res.data.status == 1) {
        var coupon_list = res.data.result.list;
        that.setData({
          coupon_list: coupon_list,
        });
      } else if (res.data.status == -1) {
        wx.switchTab({
          url: '../../wode/choice/choice',
        })
      }
    });
  },
  useCoupon: function (e) {
    var typeId = parseInt(e.currentTarget.dataset.useType);
    var goodsId = parseInt(e.currentTarget.dataset.goodsId);
    var categoryId = parseInt(e.currentTarget.dataset.categoryId);
 
    if(typeId == 0){
      wx.switchTab({
        url: '../../index/index',
      })
    } else if(typeId == 1){
      wx.navigateTo({
        url: '../../goods/details/details?objectId=' + goodsId,
      })
    } else if(typeId == 2) {
      wx.navigateTo({
        url: '../../goods/list/list?objectId=' + categoryId,
      })
    }
  },

  //上拉刷新
  onReachBottom: function () {
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function () {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1000);
    var p = that.data.p + 1;
    that.setData({
      p: p
    })
    // server.getJSON('/User/coupon/type/' + tab + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
    server.getJSON('/User/coupon/type/' + that.data.tab + '/wxtoken/' + wx.getStorageSync('wxtoken') + '/p/' + that.data.p, function (res) {
      var len = res.data.result.list.length;
      if (len > 0) {
        that.setData({
          coupon_list: that.data.coupon_list.concat(res.data.result.list),
        });
      }
    })
  },
  
  //下拉刷新
  onPullDownRefresh:function()
  {
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    this.setData({
      p: 1
    })
    this.getCoupon();
  },

});