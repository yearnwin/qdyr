var server = require('../../../utils/server');
var app = getApp();
Page({
  data: {
    coupon_list: {},
    current: 0,
    tabStates: [true, false, false],
    tabClasss: ["text-select", "text-normal", "text-normal"],
    galleryHeight: getApp().screenWidth,
    tab: 0,
    atype: 1,
    p:1,
    getCoupon:''
  },
 
  onLoad: function (options) {
    this.getCoupon(1);
  },

  //按钮
  tabClick: function (e) {
    var index = e.currentTarget.dataset.index
    var atype = parseInt(index) + 1
    var classs = ["text-normal", "text-normal", "text-normal"]
    classs[index] = "text-select"
    this.setData({ tabClasss: classs, tab: index, atype: atype })
    this.getCoupon(atype);
    
  },
  //请求
  getCoupon: function (atype) {
    var that = this
    server.getJSON('/Activity/coupon_list/atype/' + atype + '/wxtoken/' + wx.getStorageSync('wxtoken'), function (res) {
      var coupon_list = res.data.result.coupon_list;
      // console.log(coupon_list);
      that.setData({
        coupon_list: coupon_list,
      });
    });
  },

  // 领取优惠卷返回消息
  useCoupon: function (e) {
    var that = this;
    var couponId = e.currentTarget.dataset.couponId;
    var openid = app.globalData.openid;
    server.getJSON('/Activity/getCoupon/coupon_id/' + couponId + '/wxtoken/' + wx.getStorageSync('wxtoken') , function (res) {            
      wx.showToast({
        title: res.data.msg
      })
      
    });
  },

  //上拉刷新
  onReachBottom: function () {  
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    that.setData({
      p: that.data.p + 1
    })
    server.getJSON('/Activity/coupon_list/atype/' +that.data.atype + '/p/' + that.data.p + '/wxtoken/' + wx.getStorageSync('wxtoken'),function(res){ 
      var len=res.data.result.coupon_list.length;
      if(len > 0){
        that.setData({
          coupon_list: that.data.coupon_list.concat(res.data.result.coupon_list),
        });
      }
        
    })
  },

  // 下拉刷新
  onPullDownRefresh:function(e){
    var that = this
    wx.showNavigationBarLoading() //在标题栏中显示加载  
    //模拟加载
    setTimeout(function()
    {
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    },1000);
    var atype = that.data.atype;
    that.setData({
      p: 1
    })
    that.getCoupon(atype);  
  }
});