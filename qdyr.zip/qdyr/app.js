var server = require('./utils/server.js');

// 授权登录 
App({
  onLaunch: function () {
    var that = this;

    // 设备信息
    wx.getSystemInfo({
      success: function (res) {
        that.screenWidth = res.windowWidth;
        that.pixelRatio = res.pixelRatio;
      }
    });
    this.getUserInfo();
    this.getOpenId();

    // this.getOpenId(function () {
    //   var openId = getApp().globalData.openid;
    //   server.getJSON("/User/validateOpenid", { openid: openId }, function (res) {
    //     if (res.data.code == 200) {
    //       getApp().globalData.userInfo = res.data.data;
    //       getApp().globalData.login = true; 
    //     }
    //     else {
    //       if (res.data.code == '400') {
    //         // getApp().register(function () {
    //         //   getApp().globalData.login = true;
    //         // });
    //       }
    //     }
    //   });
    // });
  },
  getOpenId: function (cb) {
    wx.login({
      success: function (res) {
        if (res.code) {
          // console.log(res)
          //发起网络请求
          wx.request({
            url: 'https://qdyrxcx.zqcom.cc/index.php/wxapi/LoginApi/sendappid?appid=wx5bb2e3ccc834504d&secret=70dfe4d7a242cacad276e7cb0acdb3e5&js_code=' + res.code + '&grant_type=authorization_code',
            data: {
              code: res.code
            },
            success: function (response) {
              // 获取openId
              var openId = response.data.openid;
              // TODO 缓存 openId
              var app = getApp();
              app.globalData.openid = openId;

              var unionId = response.data.unionid;
              app.globalData.unionId = unionId;
              //验证是否关联openid
              typeof cb == "function" && cb()

              // console.log(openId)
              // console.log(unionId)
              // app.userInfo(unionId);
            }
          })
          //typeof cb == "function" && cb()
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
  },

  // register: function (cb) {
  //   var app = this;
  //   this.getUserInfo(function () {
  //     var openId = app.globalData.openid;
  //     var userInfo = app.globalData.userInfo;
  //     var country = userInfo.country;
  //     var city = userInfo.city;
  //     var gender = userInfo.gender;
  //     var nick_name = userInfo.nickName;
  //     var province = userInfo.province;
  //     var avatarUrl = userInfo.avatarUrl;
  //     server.getJSON('/User/register?open_id=' + openId + "&country=" + country + "&gender=" + gender + "&nick_name=" + nick_name + "&province=" + province + "&city=" + city + "&head_pic=" + avatarUrl, function (res) {
  //       app.globalData.userInfo = res.data.res
  //       typeof cb == "function" && cb(app.globalData.userInfo)
  //     });
  //   })
  // },
  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },

  upload_file: function (url, filePath, name, formData, success, fail) {
    if (filePath.length === 0) {
      wx.showToast({
        title: '请上传照片！',
        icon: 'loading',
        duration: 500
      })
    } else {
      wx.uploadFile({
        url: url,
        filePath: filePath,
        name: name,
        header: { 'content-type': 'multipart/form-data' }, // 设置请求的 header
        formData: formData, // HTTP 请求中其他额外的 form data
        success: function (res) {
          if (res.statusCode == 200 && !res.data.result_code) {
            return typeof success == "function" && success(res);
          } else {
            return typeof fail == "function" && fail(res);
          }
        },
        fail: function (res) {
          return typeof fail == "function" && fail(res);
        }
      })
    }
  },
  // userInfo: function (unionid) {
  //   // var unionid = this.globalData.unionId;
  //   // console.log(unionid);
  //   var app = getApp();
  //   wx.request({
  //     url: getApp().globalData.url + '/wxapi/Cart/users',
  //     data: {
  //       unionid: unionid,
  //     },
  //     method: 'POST',
  //     success: function (res) {
  //       if (res.data.status == 1) {
  //         app.globalData.login = true;
  //       } else {
  //         wx.navigateTo({
  //           url: './pages/wode/choice/choice',
  //         })
  //       }
  //     }
  //   })
  // },
  globalData: {
    userInfo:{
      'openid': null,
      'userInfo': null,
      'login': false,
      'nickName':'去登陆',
      'avatarUrl':'/img/ceshi.jpg',
      'user_id':0,
      'identity':'',
      'first_leader':'',
    
    },
    'openid': '',
    'appid': 'wx5bb2e3ccc834504d',
    'token':'',
    'url': 'https://qdyrxcx.zqcom.cc',
    'unionId':'',
    'login': false,
    'user_id': '',
  }
})
