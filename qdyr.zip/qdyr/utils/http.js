//  小程序网络请求promise封装
//  其他页面引入：import {http} from '/utils/http.js'
//  调用：
//  http(method, url, data).then(res=>{...})
const app = getApp()
const http = (method, url, data) => {
    data.wxtoken=wx.getStorageSync('wxtoken');
    return new Promise(function (resolve, reject) {
        wx.request({
            url: `${app.globalData.url}${url}`,
            method: method,
            data: data,
            header: {
                'content-type': 'application/x-www-form-urlencoded', // 默认值
            },
            success: function (res) {
                // if (res.statusCode != 200) {
                //     reject({
                //         error: '服务器忙，请稍后重试',
                //         code: 500
                //     });
                //     return;
                // }
                resolve(res);
            },
            fail: function (res) {
                // fail调用接口失败
                reject({
                    error: '网络错误',
                    code: 0
                });
            },
            complete: function (res) {
                // complete
            }
        })
    })
}
export {http}